import os
import sys
import flet as ft

# Ensure the root of the project is in python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Pyodide PWA import compatibility shim
# On the web, Flet's python-worker.js moves directories under 'src/' but doesn't create '__init__.py'.
# We create 'src/__init__.py' at runtime to make 'src' a fully importable regular package.
if not os.path.exists("src/__init__.py"):
    try:
        os.makedirs("src", exist_ok=True)
        with open("src/__init__.py", "w") as f:
            pass
    except Exception:
        pass

from src.core.theme import get_app_theme, BG_COLOR
from src.repositories.client_storage_repo import ClientStorageRepository
from src.views.main_view import MainView

def main(page: ft.Page):
    # Configure main window properties (optimized for a modern mobile screen size by default)
    page.title = "Gumlis checklista"
    page.window.width = 410
    page.window.height = 820
    page.window.min_width = 320
    page.window.min_height = 600
    page.window.resizable = True
    
    # Enable scroll on the page itself if needed, but since our views scroll internally, keep it false
    page.scroll = None
    page.padding = 0
    page.bgcolor = BG_COLOR
    
    # Apply custom premium theme (Emerald & Mint green Material 3 theme)
    page.theme = get_app_theme()
    
    # Initialize client storage repository (perfect for local desktop and web PWAs!)
    repo = ClientStorageRepository(page=page)
    
    # Mount core layout view
    app_layout = MainView(repo=repo)
    page.add(app_layout)
    page.update()

if __name__ == "__main__":
    ft.run(main)
