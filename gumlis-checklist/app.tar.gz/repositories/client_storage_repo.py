import os
import json
import logging
from datetime import datetime, timedelta
from typing import List, Optional
import flet as ft

from src.core.config import JSON_DB_PATH, HISTORY_RETENTION_DAYS
from src.core.repository import BaseRepository
from src.models.checklist import Checklist, CommonGroup, ChecklistsData, ChecklistItem

import sys

logger = logging.getLogger(__name__)

# Detect Web/Pyodide environment to access browser storage directly and safely via Flet!
IS_WEB = sys.platform == 'emscripten'

class ClientStorageRepository(BaseRepository):
    def __init__(self, page: ft.Page):
        self.page = page
        # File fallback for local desktop running
        self.desktop_file_path = JSON_DB_PATH
        self._ensure_db_exists()
        self.purge_expired_history()

    def _read_raw(self) -> Optional[str]:
        """Reads raw JSON string from either browser client_storage/localStorage (web) or local file (desktop)."""
        if IS_WEB:
            # 1. Try Flet's built-in client_storage first
            try:
                if hasattr(self.page, "client_storage") and self.page.client_storage is not None:
                    return self.page.client_storage.get("checklists_data")
            except Exception as e:
                logger.error(f"Error reading from Flet client_storage: {e}")
            
            # 2. Fallback to native browser localStorage via Pyodide's 'js' module
            try:
                import js
                content = js.window.localStorage.getItem("checklists_data")
                return content if content else None
            except Exception as e:
                logger.error(f"Error reading from native browser localStorage: {e}")
                return None
        else:
            if os.path.exists(self.desktop_file_path):
                try:
                    with open(self.desktop_file_path, "r", encoding="utf-8") as f:
                        return f.read()
                except Exception as e:
                    logger.error(f"Error reading from local desktop file: {e}")
                    return None
            return None

    def _write_raw(self, content: str) -> None:
        """Writes raw JSON string to either browser client_storage/localStorage (web) or local file (desktop)."""
        if IS_WEB:
            # 1. Try Flet's built-in client_storage first
            flet_success = False
            try:
                if hasattr(self.page, "client_storage") and self.page.client_storage is not None:
                    self.page.client_storage.set("checklists_data", content)
                    flet_success = True
            except Exception as e:
                logger.error(f"Error writing to Flet client_storage: {e}")
            
            # 2. Fallback/Sync to native browser localStorage via Pyodide's 'js' module
            try:
                import js
                js.window.localStorage.setItem("checklists_data", content)
            except Exception as e:
                logger.error(f"Error writing to native browser localStorage: {e}")
        else:
            try:
                with open(self.desktop_file_path, "w", encoding="utf-8") as f:
                    f.write(content)
            except Exception as e:
                logger.error(f"Error writing to local desktop file: {e}")

    def _ensure_db_exists(self) -> None:
        """Ensures the storage exists and is populated with default structures if empty."""
        try:
            content = self._read_raw()
            if not content:
                # Initialize empty structure with default templates and groups
                data = ChecklistsData(
                    checklists=[
                        Checklist(
                            id="active_list",
                            title="Min checklista",
                            is_template=False,
                            category_order=["Att göra", "Packning & Förskola", "Inköp", "Planering"],
                            items=[]
                        ),
                        Checklist(
                            id="later_list",
                            title="Senare",
                            is_template=False,
                            category_order=["Att göra", "Packning & Förskola", "Inköp", "Planering"],
                            items=[]
                        ),
                        Checklist(
                            id="history_list",
                            title="Historik",
                            is_template=False,
                            category_order=["Att göra", "Packning & Förskola", "Inköp", "Planering"],
                            items=[]
                        )
                    ],
                    common_groups=[
                        CommonGroup(id="group_1", name="Vanliga Uppgifter", items=["Vattna blommorna", "Morgonmeditation", "Bädda sängen", "Gå ut med soporna"]),
                        CommonGroup(id="group_2", name="Förskola Favoriter", items=["Blöjor", "Extrakläder", "Nappar", "Regnkläder"]),
                        CommonGroup(id="group_3", name="Vanliga Inköp", items=["Mjölk", "Kaffe", "Ägg", "Smör", "Bröd"])
                    ]
                )
                self._save(data)
            else:
                # Ensure history_list and later_list exist for backwards compatibility
                try:
                    data = ChecklistsData.model_validate_json(content)
                except Exception:
                    # In case of validation issues, recreate defaults
                    return
                
                has_later = any(c.id == "later_list" for c in data.checklists)
                has_history = any(c.id == "history_list" for c in data.checklists)
                modified = False
                
                if not has_later:
                    later_list = Checklist(
                        id="later_list",
                        title="Senare",
                        is_template=False,
                        category_order=["Att göra", "Packning & Förskola", "Inköp", "Planering"],
                        items=[]
                    )
                    data.checklists.append(later_list)
                    modified = True
                    
                if not has_history:
                    history_list = Checklist(
                        id="history_list",
                        title="Historik",
                        is_template=False,
                        category_order=["Att göra", "Packning & Förskola", "Inköp", "Planering"],
                        items=[]
                    )
                    data.checklists.append(history_list)
                    modified = True
                    
                if modified:
                    self._save(data)
        except Exception as e:
            logger.error(f"Error initializing database storage: {e}")

    def _read(self) -> ChecklistsData:
        try:
            content = self._read_raw()
            if not content:
                return ChecklistsData()
            return ChecklistsData.model_validate_json(content)
        except Exception as e:
            logger.error(f"Error parsing database checklists: {e}")
            return ChecklistsData()

    def _save(self, data: ChecklistsData) -> None:
        try:
            self._write_raw(data.model_dump_json(indent=2))
        except Exception as e:
            logger.error(f"Error stringifying database checklists: {e}")

    def get_all_checklists(self) -> List[Checklist]:
        data = self._read()
        return data.checklists

    def get_checklist(self, checklist_id: str) -> Optional[Checklist]:
        data = self._read()
        for checklist in data.checklists:
            if checklist.id == checklist_id:
                return checklist
        return None

    def save_checklist(self, checklist: Checklist) -> None:
        data = self._read()
        found = False
        for idx, c in enumerate(data.checklists):
            if c.id == checklist.id:
                data.checklists[idx] = checklist
                found = True
                break
        if not found:
            data.checklists.append(checklist)
        self._save(data)

    def delete_checklist(self, checklist_id: str) -> None:
        data = self._read()
        data.checklists = [c for c in data.checklists if c.id != checklist_id]
        self._save(data)

    def get_all_common_groups(self) -> List[CommonGroup]:
        data = self._read()
        return data.common_groups

    def save_common_group(self, group: CommonGroup) -> None:
        data = self._read()
        found = False
        for idx, g in enumerate(data.common_groups):
            if g.id == group.id:
                data.common_groups[idx] = group
                found = True
                break
        if not found:
            data.common_groups.append(group)
        self._save(data)

    def delete_common_group(self, group_id: str) -> None:
        data = self._read()
        data.common_groups = [g for g in data.common_groups if g.id != group_id]
        self._save(data)

    def purge_expired_history(self) -> None:
        """Purge completed/history items that are older than HISTORY_RETENTION_DAYS (14 days)."""
        try:
            data = self._read()
            history_checklist = None
            for checklist in data.checklists:
                if checklist.id == "history_list":
                    history_checklist = checklist
                    break
            
            if not history_checklist:
                return

            now = datetime.utcnow()
            cutoff = now - timedelta(days=HISTORY_RETENTION_DAYS)
            
            original_count = len(history_checklist.items)
            retained_items = []
            
            for item in history_checklist.items:
                try:
                    dt_str = item.created_at
                    if dt_str.endswith("Z"):
                        dt_str = dt_str[:-1]
                    
                    item_dt = datetime.fromisoformat(dt_str)
                    
                    if item_dt >= cutoff:
                        retained_items.append(item)
                except Exception as e:
                    logger.error(f"Error parsing item date {item.created_at} for item {item.id}: {e}")
                    retained_items.append(item)
            
            if len(retained_items) < original_count:
                logger.info(f"Purged {original_count - len(retained_items)} expired history items.")
                history_checklist.items = retained_items
                self._save(data)
        except Exception as e:
            logger.error(f"Error purging expired history: {e}")

