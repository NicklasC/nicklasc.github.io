import flet as ft
from src.core.theme import (
    TEXT_PRIMARY, TEXT_MUTED, EMERALD_GREEN, MINT_GREEN,
    SURFACE_GLASS, CATEGORY_COLORS, glass_card_style, border_all
)

class QuickAdd(ft.Container):
    def __init__(self, on_add_item, categories=None, *args, **kwargs):
        self.on_add_item = on_add_item
        self.categories = categories or ["Att göra", "Packning & Förskola", "Inköp", "Planering"]
        
        # TextField for entering text
        self.text_field = ft.TextField(
            hint_text="Skriv något att göra...",
            hint_style=ft.TextStyle(color=TEXT_MUTED, size=13),
            text_style=ft.TextStyle(color=TEXT_PRIMARY, size=13, weight=ft.FontWeight.W_500),
            bgcolor=ft.Colors.with_opacity(0.4, SURFACE_GLASS),
            border_color="#1E2E26",
            focused_border_color=MINT_GREEN,
            border_radius=16,
            content_padding=ft.Padding(left=12, top=6, right=12, bottom=6),
            expand=True,
            on_submit=self._handle_submit_default,
            autofocus=False
        )
        
        # Submit icon button
        self.submit_btn = ft.IconButton(
            icon=ft.Icons.ARROW_UPWARD_ROUNDED,
            icon_color=TEXT_PRIMARY,
            bgcolor=EMERALD_GREEN,
            icon_size=16,
            width=32,
            height=32,
            tooltip="Lägg till",
            on_click=self._handle_submit_default,
            style=ft.ButtonStyle(
                shape=ft.RoundedRectangleBorder(radius=10)
            )
        )
        
        # Category pills
        self.pills_row = ft.Row(
            controls=self._build_category_pills(),
            scroll=ft.ScrollMode.AUTO,
            alignment=ft.MainAxisAlignment.START,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=8
        )
        
        # Main layout container
        super().__init__(
            content=ft.Column(
                controls=[
                    ft.Container(
                        content=self.pills_row,
                        padding=ft.Padding(left=2, top=0, right=2, bottom=4)
                    ),
                    ft.Row(
                        controls=[
                            self.text_field,
                            self.submit_btn
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=8
                    )
                ],
                tight=True,
                spacing=0
            ),
            **glass_card_style(padding=8, border_radius=12, border_color="#1C2E25"),
            **kwargs
        )

    def _build_category_pills(self) -> list:
        pills = []
        for cat in self.categories:
            color = CATEGORY_COLORS.get(cat, EMERALD_GREEN)
            
            pills.append(
                ft.GestureDetector(
                    mouse_cursor=ft.MouseCursor.CLICK,
                    on_tap=lambda e, category=cat: self._handle_pill_click(category),
                    content=ft.Container(
                        content=ft.Row(
                            controls=[
                                ft.Icon(
                                    ft.Icons.ADD_ROUNDED,
                                    color=color,
                                    size=12
                                ),
                                ft.Text(
                                    value=category_label_short(cat),
                                    size=11,
                                    weight=ft.FontWeight.W_600,
                                    color=TEXT_PRIMARY
                                )
                            ],
                            tight=True,
                            spacing=3
                        ),
                        bgcolor=ft.Colors.with_opacity(0.12, color),
                        border=border_all(1.0, ft.Colors.with_opacity(0.3, color)),
                        border_radius=10,
                        padding=ft.Padding(left=8, top=3, right=8, bottom=3),
                    )
                )
            )
        return pills

    def _handle_pill_click(self, category: str):
        title = self.text_field.value.strip()
        if not title:
            # Shake or focus if empty
            self.text_field.focus()
            return
        
        # Add item using callback
        if self.on_add_item:
            self.on_add_item(title, category)
            
        # Reset field
        self.text_field.value = ""
        self.text_field.update()

    def _handle_submit_default(self, e):
        title = self.text_field.value.strip()
        if not title:
            self.text_field.focus()
            return
            
        # Use first category as default if none selected
        default_cat = self.categories[0] if self.categories else "Att göra"
        
        if self.on_add_item:
            self.on_add_item(title, default_cat)
            
        self.text_field.value = ""
        self.text_field.update()

def category_label_short(category: str) -> str:
    """Shortens long category names for compact display on pills if needed."""
    if category == "Packning & Förskola":
        return "Förskola"
    return category
