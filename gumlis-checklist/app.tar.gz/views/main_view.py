import flet as ft

from src.core.theme import (
    BG_COLOR, MINT_GREEN, EMERALD_GREEN, TEXT_PRIMARY, TEXT_MUTED
)
from src.views.checklist_view import ChecklistView
from src.views.templates_view import TemplatesView
from src.views.history_view import HistoryView
from src.views.later_view import LaterView

class MainView(ft.Container):
    def __init__(self, repo, *args, **kwargs):
        self.repo = repo
        
        # Pre-initialize sub-views
        self.view_checklist = ChecklistView(repo=self.repo)
        
        # When a favorite is clicked in the TemplatesView, add it and reload the checklist view
        self.view_templates = TemplatesView(
            repo=self.repo,
            on_template_added_to_active=self._handle_template_added
        )
        
        # When an item is restored in HistoryView, reload the active checklist view
        self.view_history = HistoryView(
            repo=self.repo,
            on_item_restored=self._handle_item_restored
        )
        
        # Later (backlog) view
        self.view_later = LaterView(
            repo=self.repo,
            on_item_promoted=self._handle_item_promoted
        )
        
        # Container to hold the active view
        self.content_area = ft.Container(
            content=self.view_checklist,
            expand=True
        )
        
        # Navigation Bar (Optimized for mobile bottom layout)
        self.nav_bar = ft.NavigationBar(
            destinations=[
                ft.NavigationBarDestination(
                    icon=ft.Icons.CHECKLIST_OUTLINED,
                    selected_icon=ft.Icons.CHECKLIST_ROUNDED,
                    label="Checklista"
                ),
                ft.NavigationBarDestination(
                    icon=ft.Icons.BOLT_OUTLINED,
                    selected_icon=ft.Icons.BOLT_ROUNDED,
                    label="Snabblistan"
                ),
                ft.NavigationBarDestination(
                    icon=ft.Icons.HISTORY_OUTLINED,
                    selected_icon=ft.Icons.HISTORY_ROUNDED,
                    label="Historik"
                ),
                ft.NavigationBarDestination(
                    icon=ft.Icons.ALL_INBOX_OUTLINED,
                    selected_icon=ft.Icons.ALL_INBOX_ROUNDED,
                    label="Senare"
                )
            ],
            selected_index=0,
            on_change=self._handle_nav_change,
            bgcolor="#0E1612",
            indicator_color=ft.Colors.with_opacity(0.12, MINT_GREEN),
            # Styled colors for labels and icons
        )

        super().__init__(
            content=ft.Column(
                controls=[
                    self.content_area,
                    self.nav_bar
                ],
                expand=True,
                spacing=0
            ),
            bgcolor=BG_COLOR,
            expand=True,
            **kwargs
        )

    def _handle_nav_change(self, e):
        """Switches screens and reloads their respective data for reactive UI synchronization."""
        idx = int(e.data)
        
        if idx == 0:
            self.view_checklist._load_data_and_clean()
            self.content_area.content = self.view_checklist
        elif idx == 1:
            self.view_templates._load_data()
            self.content_area.content = self.view_templates
        elif idx == 2:
            self.view_history._load_data()
            self.content_area.content = self.view_history
        elif idx == 3:
            self.view_later._load_data()
            self.content_area.content = self.view_later
            
        self.content_area.update()

    def _handle_template_added(self, title: str, group_name: str):
        """Callback from Snabblistan tab: adds the item to the active checklist and shows a snackbar."""
        self.view_checklist._add_favorite_item(title, group_name)
        
        # Show elegant feedback toast
        snack = ft.SnackBar(
            content=ft.Text(f"Lade till '{title}' i checklistan!", color=TEXT_PRIMARY),
            bgcolor="#142C20",
            duration=1500,
            open=True
        )
        self.page.overlay.append(snack)
        self.page.update()

    def _handle_item_restored(self):
        """Callback from History tab when an item is restored: forces checklist view to refresh in background."""
        self.view_checklist._load_data_and_clean()
        
        snack = ft.SnackBar(
            content=ft.Text("Uppgiften återställd till checklistan!", color=TEXT_PRIMARY),
            bgcolor="#142C20",
            duration=1500,
            open=True
        )
        self.page.overlay.append(snack)
        self.page.update()

    def _handle_item_promoted(self, item):
        """Callback from LaterView when an item is promoted to today's active checklist."""
        # Force refresh active checklist so if it loads, it will have it
        self.view_checklist._load_data_and_clean()
        
        # Show elegant feedback snackbar
        snack = ft.SnackBar(
            content=ft.Text(f"Flyttade '{item.title}' till idag!", color=TEXT_PRIMARY),
            bgcolor="#142C20",
            duration=1500,
            open=True
        )
        self.page.overlay.append(snack)
        self.page.update()
