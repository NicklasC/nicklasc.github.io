import uuid
import flet as ft

from src.core.theme import (
    TEXT_PRIMARY, TEXT_MUTED, TEXT_SECONDARY,
    EMERALD_GREEN, MINT_GREEN, glass_card_style,
    SURFACE_COLOR, SURFACE_GLOW, border_all
)
from src.models.checklist import CommonGroup

class TemplatesView(ft.Container):
    def __init__(self, repo, on_template_added_to_active, *args, **kwargs):
        self.repo = repo
        self.on_template_added_to_active = on_template_added_to_active
        self.groups = []
        
        # Main layout container
        self.cards_container = ft.Column(
            scroll=ft.ScrollMode.AUTO,
            spacing=8,
            expand=True
        )
        
        # Header Row
        self.header_row = ft.Row(
            controls=[
                ft.Column(
                    controls=[
                        ft.Text(
                            value="Snabblistan",
                            size=22,
                            weight=ft.FontWeight.W_800,
                            color=TEXT_PRIMARY
                        ),
                        ft.Text(
                            value="Hantera dina vanligaste favoritmallar",
                            size=12,
                            weight=ft.FontWeight.W_500,
                            color=TEXT_SECONDARY
                        )
                    ],
                    spacing=2,
                    tight=True
                ),
                ft.IconButton(
                    icon=ft.Icons.ADD_BOX_ROUNDED,
                    icon_color=MINT_GREEN,
                    icon_size=24,
                    tooltip="Ny favoritgrupp",
                    on_click=self._show_add_group_dialog,
                    style=ft.ButtonStyle(
                        bgcolor=ft.Colors.with_opacity(0.1, MINT_GREEN),
                        shape=ft.RoundedRectangleBorder(radius=12)
                    )
                )
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.CENTER
        )

        self._load_data()

        super().__init__(
            content=ft.Column(
                controls=[
                    ft.Container(content=self.header_row, padding=ft.Padding(left=0, top=0, right=0, bottom=8)),
                    self.cards_container
                ],
                expand=True,
                spacing=0
            ),
            padding=ft.Padding(left=12, top=6, right=12, bottom=6),
            expand=True,
            **kwargs
        )

    def _is_mounted(self):
        if not hasattr(self, '_i'):
            return False
        try:
            return self.page is not None
        except (RuntimeError, AttributeError):
            return False

    def _load_data(self):
        """Loads all template groups and renders their management cards."""
        self.groups = self.repo.get_all_common_groups()
        self._refresh_cards()

    def _refresh_cards(self):
        self.cards_container.controls.clear()
        
        if not self.groups:
            self.cards_container.controls.append(
                ft.Container(
                    content=ft.Column(
                        controls=[
                            ft.Icon(ft.Icons.LAYERS_CLEAR_ROUNDED, size=48, color=ft.Colors.with_opacity(0.3, MINT_GREEN)),
                            ft.Text(value="Inga favoritgrupper än", size=16, weight=ft.FontWeight.BOLD, color=TEXT_PRIMARY),
                            ft.Text(value="Skapa en ny grupp för att spara dina vanligaste rutiner.", size=12, color=TEXT_MUTED, text_align=ft.TextAlign.CENTER)
                        ],
                        alignment=ft.MainAxisAlignment.CENTER,
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=10
                    ),
                    alignment=ft.Alignment.CENTER,
                    padding=ft.Padding(left=0, top=40, right=0, bottom=40)
                )
            )
            if self._is_mounted():
                self.cards_container.update()
            return

        for group in self.groups:
            card = self._build_group_card(group)
            self.cards_container.controls.append(card)
        if self._is_mounted():
            self.cards_container.update()

    def _build_group_card(self, group: CommonGroup) -> ft.Container:
        # Pills for each item in the template group
        pills = []
        for item in group.items:
            pills.append(
                ft.Container(
                    content=ft.Row(
                        controls=[
                            ft.GestureDetector(
                                mouse_cursor=ft.MouseCursor.CLICK,
                                on_tap=lambda e, val=item, gname=group.name: self._handle_item_tap(val, gname),
                                content=ft.Text(
                                    value=item,
                                    size=11,
                                    weight=ft.FontWeight.W_500,
                                    color=TEXT_PRIMARY
                                )
                            ),
                            ft.GestureDetector(
                                mouse_cursor=ft.MouseCursor.CLICK,
                                on_tap=lambda e, val=item, grp=group: self._remove_item_from_group(val, grp),
                                content=ft.Icon(
                                    ft.Icons.CLOSE_ROUNDED,
                                    size=10,
                                    color=ft.Colors.RED_300
                                )
                            )
                        ],
                        tight=True,
                        spacing=4
                    ),
                    bgcolor=ft.Colors.with_opacity(0.15, SURFACE_GLOW),
                    border=border_all(1.0, "#23332A"),
                    border_radius=8,
                    padding=ft.Padding(left=6, top=3, right=6, bottom=3),
                )
            )

        # Inner add-item row for this specific group
        new_item_field = ft.TextField(
            hint_text="Ny favorit...",
            hint_style=ft.TextStyle(color=TEXT_MUTED, size=11),
            text_style=ft.TextStyle(color=TEXT_PRIMARY, size=11),
            bgcolor=ft.Colors.with_opacity(0.2, SURFACE_COLOR),
            border_color="#1E2E26",
            focused_border_color=MINT_GREEN,
            border_radius=10,
            content_padding=ft.Padding(left=8, top=4, right=8, bottom=4),
            height=24,
            expand=True,
        )
        
        # Save reference to read it on submit
        new_item_field.on_submit = lambda e, grp=group, tf=new_item_field: self._add_item_to_group(tf, grp)

        add_btn = ft.IconButton(
            icon=ft.Icons.ADD_ROUNDED,
            icon_color=TEXT_PRIMARY,
            bgcolor=EMERALD_GREEN,
            icon_size=10,
            width=24,
            height=24,
            on_click=lambda e, grp=group, tf=new_item_field: self._add_item_to_group(tf, grp),
            style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=8))
        )

        card_content = ft.Column(
            controls=[
                ft.Row(
                    controls=[
                        ft.Text(
                            value=group.name,
                            size=14,
                            weight=ft.FontWeight.BOLD,
                            color=TEXT_PRIMARY
                        ),
                        ft.IconButton(
                            icon=ft.Icons.DELETE_OUTLINE_ROUNDED,
                            icon_color=ft.Colors.RED_300,
                            icon_size=16,
                            tooltip="Ta bort grupp",
                            on_click=lambda e, grp=group: self._delete_group(grp)
                        )
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                ),
                ft.Container(
                    content=ft.Row(
                        controls=pills,
                        wrap=True,
                        spacing=6,
                        run_spacing=6
                    ),
                    padding=ft.Padding(left=0, top=2, right=0, bottom=2) if pills else 0
                ),
                ft.Row(
                    controls=[
                        new_item_field,
                        add_btn
                    ],
                    spacing=6
                )
            ],
            spacing=4,
            tight=True
        )

        return ft.Container(
            content=card_content,
            **glass_card_style(padding=8, border_radius=12, border_color="#1C2E25")
        )

    def _handle_item_tap(self, title: str, group_name: str):
        """Triggers the callback when she taps a favorite item to add it directly to the active checklist."""
        if self.on_template_added_to_active:
            self.on_template_added_to_active(title, group_name)

    def _add_item_to_group(self, text_field: ft.TextField, group: CommonGroup):
        title = text_field.value.strip()
        if not title:
            return
        
        # Avoid duplicates in template group
        if title not in group.items:
            group.items.append(title)
            self.repo.save_common_group(group)
            
        text_field.value = ""
        self._load_data()

    def _remove_item_from_group(self, item_title: str, group: CommonGroup):
        if item_title in group.items:
            group.items.remove(item_title)
            self.repo.save_common_group(group)
            self._load_data()

    def _delete_group(self, group: CommonGroup):
        # Use the newly defined, clean repo delete method
        self.repo.delete_common_group(group.id)
        self._load_data()

    def _show_add_group_dialog(self, e):
        """Displays an overlay or prompt to create a new group."""
        # In Flet, dialogs are simple. Let's create an input dialog.
        def close_dlg(e):
            self.page.pop_dialog()

        def create_group(e):
            group_name = new_group_name_field.value.strip()
            if not group_name:
                return
            
            new_group = CommonGroup(
                id=f"group_{uuid.uuid4().hex[:8]}",
                name=group_name,
                items=[]
            )
            self.repo.save_common_group(new_group)
            
            self.page.pop_dialog()
            self._load_data()

        new_group_name_field = ft.TextField(
            label="Namn på favoritgruppen",
            label_style=ft.TextStyle(color=TEXT_SECONDARY),
            hint_text="t.ex. Träning, Fredagsmys...",
            hint_style=ft.TextStyle(color=TEXT_MUTED),
            text_style=ft.TextStyle(color=TEXT_PRIMARY),
            focused_border_color=MINT_GREEN,
            border_color="#1E2E26",
            border_radius=8,
            autofocus=True
        )

        dlg = ft.AlertDialog(
            title=ft.Text("Skapa ny favoritgrupp", color=TEXT_PRIMARY, size=16, weight=ft.FontWeight.BOLD),
            content=new_group_name_field,
            actions=[
                ft.TextButton("Avbryt", on_click=close_dlg, style=ft.ButtonStyle(color=TEXT_MUTED)),
                ft.ElevatedButton("Skapa", on_click=create_group, style=ft.ButtonStyle(bgcolor=EMERALD_GREEN, color=TEXT_PRIMARY))
            ],
            actions_alignment=ft.MainAxisAlignment.END,
            bgcolor="#121A16",
        )
        self.page.show_dialog(dlg)
