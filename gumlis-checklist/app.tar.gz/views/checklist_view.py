import uuid
from datetime import datetime
import flet as ft

from src.core.config import DEFAULT_CATEGORIES
from src.core.theme import (
    TEXT_PRIMARY, TEXT_MUTED, TEXT_SECONDARY,
    EMERALD_GREEN, MINT_GREEN, CATEGORY_COLORS,
    glass_card_style, SURFACE_COLOR, border_all
)
from src.models.checklist import Checklist, ChecklistItem
from src.views.components.item_card import ItemCard
from src.views.components.quick_add import QuickAdd

def _get_swedish_date() -> str:
    now = datetime.now()
    months = {
        1: "januari", 2: "februari", 3: "mars", 4: "april", 5: "maj", 6: "juni",
        7: "juli", 8: "augusti", 9: "september", 10: "oktober", 11: "november", 12: "december"
    }
    days_of_week = {
        0: "måndag", 1: "tisdag", 2: "onsdag", 3: "torsdag", 4: "fredag", 5: "lördag", 6: "söndag"
    }
    day_name = days_of_week[now.weekday()]
    month_name = months[now.month]
    return f"{day_name.capitalize()}, {now.day} {month_name}"

class ChecklistView(ft.Container):
    def __init__(self, repo, *args, **kwargs):
        self.repo = repo
        self.active_list = None
        self.common_groups = []
        self.snabblistan_expanded = False
        
        # Main list container
        self.list_container = ft.Column(
            scroll=ft.ScrollMode.AUTO,
            spacing=5,
            expand=True
        )
        
        # Expandable Snabblistan panel
        self.snabblistan_container = ft.Container(
            content=ft.Column(tight=True),
            visible=False,
            animate=ft.Animation(300, ft.AnimationCurve.DECELERATE),
        )
        
        # Header Row (Title and Snabblistan toggle)
        self.header_row = ft.Row(
            controls=[
                ft.Column(
                    controls=[
                        ft.Text(
                            value="Gumlis checklista",
                            size=22,
                            weight=ft.FontWeight.W_800,
                            color=TEXT_PRIMARY
                        ),
                        ft.Text(
                            value=_get_swedish_date(),
                            size=12,
                            weight=ft.FontWeight.W_500,
                            color=TEXT_SECONDARY
                        )
                    ],
                    spacing=2,
                    tight=True
                ),
                ft.IconButton(
                    icon=ft.Icons.BOLT_ROUNDED,
                    icon_color=MINT_GREEN,
                    icon_size=22,
                    tooltip="Snabblistan",
                    on_click=self._toggle_snabblistan,
                    style=ft.ButtonStyle(
                        bgcolor=ft.Colors.with_opacity(0.1, MINT_GREEN),
                        shape=ft.RoundedRectangleBorder(radius=12)
                    )
                )
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.CENTER
        )
        
        # Initialize active list and run daily clean-up
        self._load_data_and_clean()
        
        # Quick add component
        self.quick_add = QuickAdd(
            on_add_item=self._add_new_item,
            categories=self.active_list.category_order if self.active_list else DEFAULT_CATEGORIES
        )

        super().__init__(
            content=ft.Column(
                controls=[
                    ft.Container(content=self.header_row, padding=ft.Padding(left=0, top=0, right=0, bottom=6)),
                    self.snabblistan_container,
                    ft.Container(
                        content=self.list_container,
                        expand=True,
                        padding=ft.Padding(left=0, top=2, right=0, bottom=2)
                    ),
                    ft.Container(content=self.quick_add, padding=ft.Padding(left=0, top=6, right=0, bottom=0))
                ],
                expand=True,
                spacing=0
            ),
            padding=ft.Padding(left=12, top=6, right=12, bottom=6),
            expand=True,
            **kwargs
        )

    def _is_mounted(self):
        """Check if this control is mounted on a page."""
        if not hasattr(self, '_i'):
            return False
        try:
            return self.page is not None
        except (RuntimeError, AttributeError):
            return False

    def _load_data_and_clean(self):
        """Loads active checklist, runs daily cleanup of completed items, and fetches favorites."""
        # 1. Get active list
        self.active_list = self.repo.get_checklist("active_list")
        if not self.active_list:
            # Fallback if somehow not found
            self.active_list = Checklist(
                id="active_list",
                title="Min checklista",
                items=[]
            )
            self.repo.save_checklist(self.active_list)
            
        # 2. Run Daily Clean-up if date changed
        today_str = datetime.now().date().isoformat()
        if self.active_list.last_cleaned_date != today_str:
            self._perform_daily_cleanup(today_str)
            
        # 3. Load common groups (favorites)
        self.common_groups = self.repo.get_all_common_groups()
        
        # 4. Populate views
        self._refresh_snabblistan()
        self._refresh_checklist_items()

    def _perform_daily_cleanup(self, today_str: str):
        """Archives completed tasks to history and resets the daily flag."""
        checked_items = [item for item in self.active_list.items if item.is_checked]
        if checked_items:
            history_list = self.repo.get_checklist("history_list")
            if not history_list:
                history_list = Checklist(
                    id="history_list",
                    title="Historik",
                    items=[]
                )
            
            # Timestamp the archived items with current time for their 14-day retention
            now_iso = datetime.utcnow().isoformat() + "Z"
            for item in checked_items:
                item.created_at = now_iso
                # Keep active status in history so they are rendered as completed in history
                item.is_checked = True
                history_list.items.append(item)
                
            self.repo.save_checklist(history_list)
            
            # Remove completed from active
            self.active_list.items = [item for item in self.active_list.items if not item.is_checked]
            
        self.active_list.last_cleaned_date = today_str
        self.repo.save_checklist(self.active_list)

    def _refresh_snabblistan(self):
        """Builds the horizontal scrollable quick re-add pills from templates."""
        pills = []
        for group in self.common_groups:
            for item_name in group.items:
                # Skip if already exists active in list (optional, but let's keep it simple)
                pills.append(
                    ft.GestureDetector(
                        mouse_cursor=ft.MouseCursor.CLICK,
                        on_tap=lambda e, name=item_name, gname=group.name: self._add_favorite_item(name, gname),
                        content=ft.Container(
                            content=ft.Row(
                                controls=[
                                    ft.Icon(ft.Icons.BOLT_ROUNDED, color=MINT_GREEN, size=12),
                                    ft.Text(value=item_name, size=12, weight=ft.FontWeight.W_500, color=TEXT_PRIMARY)
                                ],
                                tight=True,
                                spacing=4
                            ),
                            bgcolor=ft.Colors.with_opacity(0.08, MINT_GREEN),
                            border=border_all(1.0, ft.Colors.with_opacity(0.2, MINT_GREEN)),
                            border_radius=8,
                            padding=ft.Padding(left=8, top=3, right=8, bottom=3),
                        )
                    )
                )

        if not pills:
            self.snabblistan_container.content = ft.Container(
                content=ft.Text("Inga sparade favoriter. Lägg till i Snabblistan!", size=12, color=TEXT_MUTED),
                padding=ft.Padding(left=0, top=8, right=0, bottom=8)
            )
            return

        self.snabblistan_container.content = ft.Column(
            controls=[
                ft.Text("Snabblistan (Klicka för att lägga till)", size=11, color=TEXT_SECONDARY, weight=ft.FontWeight.W_600),
                ft.Container(
                    content=ft.Row(
                        controls=pills,
                        scroll=ft.ScrollMode.AUTO,
                        spacing=8,
                    ),
                    padding=ft.Padding(left=0, top=2, right=0, bottom=4)
                )
            ],
            spacing=4,
            tight=True
        )

    def _toggle_snabblistan(self, e):
        self.snabblistan_expanded = not self.snabblistan_expanded
        self.snabblistan_container.visible = self.snabblistan_expanded
        self.update()

    def _refresh_checklist_items(self):
        """Sorts and displays active checklist items by category, with unchecked first."""
        self.list_container.controls.clear()
        
        if not self.active_list.items:
            # Empty state
            self.list_container.controls.append(
                ft.Container(
                    content=ft.Column(
                        controls=[
                            ft.Icon(ft.Icons.CHECKLIST_ROUNDED, size=48, color=ft.Colors.with_opacity(0.3, MINT_GREEN)),
                            ft.Text(value="Allt klart för idag!", size=16, weight=ft.FontWeight.BOLD, color=TEXT_PRIMARY),
                            ft.Text(value="Skriv in en uppgift eller välj från Snabblistan nedan.", size=12, color=TEXT_MUTED, text_align=ft.TextAlign.CENTER)
                        ],
                        alignment=ft.MainAxisAlignment.CENTER,
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=10
                    ),
                    alignment=ft.Alignment.CENTER,
                    padding=ft.Padding(left=0, top=40, right=0, bottom=40)
                )
            )
            if self._is_mounted():
                self.list_container.update()
            return

        # Group items by category
        items_by_cat = {}
        for item in self.active_list.items:
            items_by_cat.setdefault(item.category, []).append(item)

        # Draw category sections
        # Respect the category order of the checklist
        for category in self.active_list.category_order:
            cat_items = items_by_cat.get(category, [])
            if not cat_items:
                continue # Space-saving: hide category sections with zero items

            # Split unchecked and checked items
            unchecked = [item for item in cat_items if not item.is_checked]
            checked = [item for item in cat_items if item.is_checked]

            # Sort items by date/creation within sub-group
            unchecked.sort(key=lambda x: x.created_at)
            checked.sort(key=lambda x: x.created_at)

            # Category Header
            color = CATEGORY_COLORS.get(category, EMERALD_GREEN)
            header = ft.Container(
                content=ft.Row(
                    controls=[
                        ft.Container(width=8, height=8, bgcolor=color, border_radius=4),
                        ft.Text(
                            value=category.upper(),
                            size=11,
                            weight=ft.FontWeight.W_700,
                            color=TEXT_SECONDARY
                        ),
                        ft.Text(
                            value=f"({len(unchecked)})" if unchecked else "",
                            size=10,
                            color=TEXT_MUTED
                        )
                    ],
                    spacing=6,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER
                ),
                padding=ft.Padding(left=4, top=6, right=0, bottom=2)
            )
            
            self.list_container.controls.append(header)

            # Render item cards (unchecked first, then checked)
            for item in unchecked + checked:
                card = ItemCard(
                    item=item,
                    on_check_changed=self._handle_item_check,
                    on_deleted=self._handle_item_delete,
                    on_move_to_later=self._handle_item_move_to_later
                )
                self.list_container.controls.append(card)

        if self._is_mounted():
            self.list_container.update()

    def _add_new_item(self, title: str, category: str):
        """Adds a new manual item to the active list."""
        new_item = ChecklistItem(
            id=f"item_{uuid.uuid4().hex[:8]}",
            title=title,
            is_checked=False,
            category=category
        )
        self.active_list.items.append(new_item)
        self.repo.save_checklist(self.active_list)
        
        # Refresh and show
        self._refresh_checklist_items()

    def _add_favorite_item(self, title: str, group_name: str):
        """Instantly adds a favorite template item. Maps group names to standard categories."""
        # Simple mapping from favorite groups to Swedish categories
        category = "Att göra"
        if "Förskola" in group_name:
            category = "Packning & Förskola"
        elif "Inköp" in group_name:
            category = "Inköp"
        elif "Uppgifter" in group_name:
            category = "Att göra"

        new_item = ChecklistItem(
            id=f"item_{uuid.uuid4().hex[:8]}",
            title=title,
            is_checked=False,
            category=category
        )
        
        # Avoid duplicate active items with the exact same name in the same category
        exists = any(i.title == title and i.category == category and not i.is_checked for i in self.active_list.items)
        if exists:
            return

        self.active_list.items.append(new_item)
        self.repo.save_checklist(self.active_list)
        self._refresh_checklist_items()

    def _handle_item_check(self, item: ChecklistItem):
        """Saves checklist when an item checked state changes and sorts/refreshes."""
        self.repo.save_checklist(self.active_list)
        # Re-sort list so checked items move down smoothly
        # Wait, instead of drawing immediately, we can delay a tiny bit for animations to look clean
        # But a straight refresh is standard Flet. Let's do it immediately
        self._refresh_checklist_items()

    def _handle_item_delete(self, item: ChecklistItem):
        """Deletes item from checklist with deletion animation/feedback."""
        self.active_list.items = [i for i in self.active_list.items if i.id != item.id]
        self.repo.save_checklist(self.active_list)
        self._refresh_checklist_items()

    def _handle_item_move_to_later(self, item: ChecklistItem):
        """Moves an item from active_list to later_list."""
        # 1. Remove from active_list
        self.active_list.items = [i for i in self.active_list.items if i.id != item.id]
        self.repo.save_checklist(self.active_list)
        
        # 2. Add to later_list
        later_list = self.repo.get_checklist("later_list")
        if not later_list:
            later_list = Checklist(
                id="later_list",
                title="Senare",
                items=[]
            )
        
        # Reset check state and update timestamp
        item.is_checked = False
        item.created_at = datetime.utcnow().isoformat() + "Z"
        later_list.items.append(item)
        self.repo.save_checklist(later_list)
        
        # 3. Refresh our view
        self._refresh_checklist_items()
        
        # 4. Show Snackbar notification
        if self.page:
            snack = ft.SnackBar(
                content=ft.Text(f"Flyttade '{item.title}' till Senare!", color=TEXT_PRIMARY),
                bgcolor="#142C20",
                duration=1500,
                open=True
            )
            self.page.overlay.append(snack)
            self.page.update()
