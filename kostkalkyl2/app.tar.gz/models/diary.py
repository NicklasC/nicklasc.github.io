from datetime import date, datetime
from typing import List, Optional
from pydantic import BaseModel, Field

class Recipe(BaseModel):
    Receptnamn: str
    Protein_g: float = 0.0
    Fett_g: float = 0.0
    Kolhydrater_g: float = 0.0
    Kcal: float = 0.0
    Ingredienser: Optional[str] = ""
    Instruktioner: Optional[str] = ""
    is_breakfast: bool = False
    is_lunch: bool = False
    is_dinner: bool = False
    is_snack: bool = False
    is_goodie: bool = False
    is_ready_meal: bool = False
    is_own_meal: bool = False

class MealLogEntry(BaseModel):
    Datum: str  # YYYY-MM-DD
    Typ: str = "Mat"
    Namn: str
    Mängd: float = 1.0  # multiplier/portion count
    Kcal: float = 0.0
    Protein: float = 0.0
    Fett: float = 0.0
    Kolhydrater: float = 0.0
    Kategori: str  # Frukost, Lunch, Middag, Mellanmål, Övrigt

class TrainingLogEntry(BaseModel):
    Datum: str  # YYYY-MM-DD
    Typ: str = "Träning"
    Namn: str
    Mängd: float = 1.0  # steps or duration
    Kcal: float = 0.0
    Kategori: Optional[str] = "Träning"

class MeasurementEntry(BaseModel):
    användarid: int = 1
    datum: str  # YYYY-MM-DD
    angiven_vikt: float = 0.0
    midjemått_cm: float = 0.0

class CalSettingsEntry(BaseModel):
    användarid: int = 1
    datum: str  # YYYY-MM-DD
    aktivitetsnivå: float = 1.2
    viktnedgång_kg_vecka: float = 0.5
    protein_g_kg: float = 2.5
    fett_g_kg: float = 0.7
    makromål_protein: float = 0.0
    makromål_fett: float = 0.0
    makromål_kolhydrat: float = 0.0
    kalorier_for_jämnvikt: float = 0.0
    kalorimål_för_viktnedgång: float = 0.0
    dist_breakfast: float = 25.0
    dist_lunch: float = 30.0
    dist_dinner: float = 30.0
    dist_snack: float = 15.0