try:
    import pyodide_http
    pyodide_http.patch_all()
except ImportError:
    pass

import os
import sys

# Ensure root directory is on the path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.append(parent_dir)
if current_dir not in sys.path:
    sys.path.append(current_dir)

# Create a virtual 'src' folder structure if running in Pyodide/Web environment
# where contents of src/ are unpacked directly to the root (/home/pyodide/)
if not os.path.exists("src"):
    try:
        os.makedirs("src", exist_ok=True)
        for folder in ["core", "views", "repositories", "models"]:
            if os.path.exists(folder) and not os.path.exists(os.path.join("src", folder)):
                try:
                    # Emscripten MEMFS supports standard POSIX symlinks
                    os.symlink(os.path.join("..", folder), os.path.join("src", folder))
                except Exception:
                    pass
        with open(os.path.join("src", "__init__.py"), "w") as f:
            pass
    except Exception as e:
        print("Failed to setup virtual src package:", e)

import flet as ft
from src.core.theme import get_app_theme, BG_COLOR
from src.core.config import load_google_credentials
from src.repositories.google_sheets_repo import GoogleSheetsRepository
from src.views.main_view import MainView
from src.views.setup_view import SetupView

async def main(page: ft.Page):
    try:
        os.makedirs("scratch", exist_ok=True)
        with open("scratch/live_main_entered.txt", "w", encoding="utf-8") as f:
            f.write("main function entered successfully!\n")
    except Exception:
        pass
    try:
        # Configure main window properties (matching Gumlis Checklist mobile-first style)
        page.title = "KostKalkyl"
        
        # Safeguard window properties in case of web compatibility limits
        try:
            page.window.width = 410
            page.window.height = 820
            page.window.min_width = 320
            page.window.min_height = 600
            page.window.resizable = True
        except Exception:
            pass
        
        page.padding = 0
        page.bgcolor = BG_COLOR
        
        # Apply custom premium material 3 theme
        page.theme = get_app_theme()
        
        # Success callback to transit from SetupView to MainView
        def on_setup_success(connected_repo):
            page.clean()
            page.add(MainView(repo=connected_repo))
            
        # 1. Try to load credentials from shared_preferences (handles both JSON string and fallback raw dict)
        creds_data = await page.shared_preferences.get("google_credentials")
        spreadsheet_url = await page.shared_preferences.get("spreadsheet_url")
        
        creds_info = None
        if creds_data is not None:
            if isinstance(creds_data, dict):
                creds_info = creds_data
            else:
                try:
                    import json
                    creds_info = json.loads(creds_data)
                except Exception:
                    pass
        
        repo = None
        
        # 2. If not in shared_preferences, check if local fallback (secrets.toml) exists
        if creds_info is None or spreadsheet_url is None:
            try:
                creds_info, spreadsheet_url = load_google_credentials()
            except Exception as e:
                # Local fallback failed or does not exist (expected in production/web)
                pass
                
        # 3. Try to initialize repository if we got credentials
        if creds_info is not None and spreadsheet_url is not None:
            try:
                repo = GoogleSheetsRepository(creds_info=creds_info, spreadsheet_url=spreadsheet_url)
                # Quick verification query to verify sheet connection
                repo.get_latest_measurement()
            except Exception as conn_err:
                # Connection failed, clear repo so we fall back to setup view
                repo = None
                
        # 4. Route based on connection success
        if repo is not None:
            page.add(MainView(repo=repo))
        else:
            page.add(SetupView(on_success=on_setup_success))
            
    except Exception as e:
        import traceback
        try:
            os.makedirs("scratch", exist_ok=True)
            with open("scratch/error.log", "w", encoding="utf-8") as f:
                f.write(f"Exception in main: {e}\n")
                f.write(traceback.format_exc())
        except Exception:
            pass
        raise e

if __name__ == "__main__":
    ft.run(main, view=ft.AppView.WEB_BROWSER, host="127.0.0.1", port=8550)