try:
    import pyodide_http
    pyodide_http.patch_all()
except ImportError:
    pass

import os
import sys

# Ensure root directory is on the path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.append(parent_dir)
if current_dir not in sys.path:
    sys.path.append(current_dir)

# Create a virtual 'src' folder structure if running in Pyodide/Web environment
# where contents of src/ are unpacked directly to the root (/home/pyodide/)
if not os.path.exists("src"):
    try:
        os.makedirs("src", exist_ok=True)
        for folder in ["core", "views", "repositories", "models"]:
            if os.path.exists(folder) and not os.path.exists(os.path.join("src", folder)):
                try:
                    # Emscripten MEMFS supports standard POSIX symlinks
                    os.symlink(os.path.join("..", folder), os.path.join("src", folder))
                except Exception:
                    pass
        with open(os.path.join("src", "__init__.py"), "w") as f:
            pass
    except Exception as e:
        print(f"Failed to setup virtual src package ({type(e).__name__})")

import flet as ft
from src.core.theme import get_app_theme, BG_COLOR
from src.core.config import load_google_credentials
from src.core.credential_store import (
    ENCRYPTED_CREDENTIALS_KEY,
    LEGACY_PLAINTEXT_CREDENTIALS_KEY,
    SPREADSHEET_URL_KEY,
)
from src.repositories.google_sheets_repo import GoogleSheetsRepository
from src.views.main_view import MainView
from src.views.setup_view import SetupView

async def main(page: ft.Page):
    try:
        # Configure main window properties (matching Gumlis Checklist mobile-first style)
        page.title = "KostKalkyl"
        
        # Safeguard window properties in case of web compatibility limits
        try:
            page.window.width = 410
            page.window.height = 820
            page.window.min_width = 320
            page.window.min_height = 600
            page.window.resizable = True
        except Exception:
            pass
        
        page.padding = 0
        page.bgcolor = BG_COLOR
        
        # Apply custom premium material 3 theme
        page.theme = get_app_theme()
        
        # Success callback to transit from SetupView to MainView
        def on_setup_success(connected_repo):
            page.clean()
            page.add(MainView(repo=connected_repo))
            
        preferences = ft.SharedPreferences()
        encrypted_credentials = await preferences.get(ENCRYPTED_CREDENTIALS_KEY)
        spreadsheet_url = await preferences.get(SPREADSHEET_URL_KEY)

        # Old releases stored the private key in plaintext. Remove that value
        # without reading or migrating it; the user must save it encrypted once.
        legacy_credentials = await preferences.get(LEGACY_PLAINTEXT_CREDENTIALS_KEY)
        if legacy_credentials is not None:
            await preferences.remove(LEGACY_PLAINTEXT_CREDENTIALS_KEY)

        if encrypted_credentials is not None:
            page.add(
                SetupView(
                    on_success=on_setup_success,
                    encrypted_credentials=encrypted_credentials,
                    spreadsheet_url=spreadsheet_url,
                )
            )
            return

        repo = None
        creds_info = None

        # A local secrets file remains supported for non-browser development.
        try:
            creds_info, local_spreadsheet_url = load_google_credentials()
            spreadsheet_url = spreadsheet_url or local_spreadsheet_url
        except Exception:
            pass

        if creds_info is not None and spreadsheet_url is not None:
            try:
                repo = GoogleSheetsRepository(creds_info=creds_info, spreadsheet_url=spreadsheet_url)
                # Quick verification query to verify sheet connection
                repo.get_latest_measurement()
            except Exception:
                # Connection failed, clear repo so we fall back to setup view
                repo = None

        if repo is not None:
            page.add(MainView(repo=repo))
        else:
            page.add(
                SetupView(
                    on_success=on_setup_success,
                    spreadsheet_url=spreadsheet_url,
                )
            )
            
    except Exception as e:
        print(f"App startup failed ({type(e).__name__})")
        try:
            page.clean()
            page.add(
                ft.Text(
                    "Appen kunde inte starta. Ladda om sidan och försök igen.",
                    color=ft.Colors.RED_400,
                )
            )
        except Exception:
            pass

if __name__ == "__main__":
    ft.run(main, view=ft.AppView.WEB_BROWSER, host="127.0.0.1", port=8550)
