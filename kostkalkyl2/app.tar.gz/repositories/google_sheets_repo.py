import os
import pandas as pd
import gspread
from datetime import datetime, date, timedelta
from google.oauth2.service_account import Credentials
from src.core.config import (
    load_google_credentials,
    RECIPES_SHEET,
    TRAINING_SHEET,
    MEAL_LOG_SHEET,
    TRAINING_LOG_SHEET,
    MEASUREMENTS_SHEET,
    CALC_SETTINGS_SHEET,
    RECEPTBANK_URL,
    RECEPTBANK_SHEET
)
from src.core.calculations import calculate_macro_goals

def safe_float(val, default=0.0) -> float:
    """Safely converts a value to float, handling Swedish commas and invalid inputs."""
    if val is None or val == "":
        return default
    val_str = str(val).strip().replace(",", ".")
    try:
        return float(val_str)
    except ValueError:
        return default

class GoogleSheetsRepository:
    def __init__(self, creds_info: dict = None, spreadsheet_url: str = None):
        # Load credentials if not injected
        if creds_info is None or spreadsheet_url is None:
            creds_info, spreadsheet_url = load_google_credentials()
            
        self.spreadsheet_url = spreadsheet_url
        
        # Scopes
        scopes = [
            "https://spreadsheets.google.com/feeds",
            "https://www.googleapis.com/auth/drive"
        ]
        
        # Authorize client
        self.creds = Credentials.from_service_account_info(creds_info, scopes=scopes)
        self.client = gspread.authorize(self.creds)
        self.sh = self.client.open_by_url(self.spreadsheet_url)
        
        # Cache for loaded DataFrames to reduce API calls
        self._cache = {}

    def _get_df(self, sheet_name: str, force_refresh: bool = False) -> pd.DataFrame:
        """Reads a worksheet from the main spreadsheet as a pandas DataFrame."""
        if not force_refresh and sheet_name in self._cache:
            return self._cache[sheet_name]
            
        try:
            wks = self.sh.worksheet(sheet_name)
            data = wks.get_all_values()
            if not data or len(data) == 0:
                df = pd.DataFrame()
            else:
                headers = [h.strip() for h in data[0]]
                rows = data[1:]
                df = pd.DataFrame(rows, columns=headers)
                # Convert all columns to object to avoid strict Arrow/String indexers TypeErrors on writes
                df = df.astype(object)
            
            self._cache[sheet_name] = df
            return df
        except gspread.exceptions.WorksheetNotFound:
            return pd.DataFrame()
        except Exception as e:
            print(f"Error reading sheet {sheet_name}: {e}")
            return pd.DataFrame()

    def _save_df(self, sheet_name: str, df: pd.DataFrame):
        """Saves a pandas DataFrame back to a worksheet, creating it if needed."""
        try:
            try:
                wks = self.sh.worksheet(sheet_name)
            except gspread.exceptions.WorksheetNotFound:
                wks = self.sh.add_worksheet(title=sheet_name, rows="1000", cols="20")
                
            wks.clear()
            # Clean dataframe values to strings for easy serialization to Sheets
            df_to_save = df.fillna("")
            headers = df_to_save.columns.tolist()
            rows = df_to_save.values.tolist()
            wks.update(range_name="A1", values=[headers] + rows)
            
            # Update cache
            self._cache[sheet_name] = df
        except Exception as e:
            print(f"Error saving sheet {sheet_name}: {e}")
            raise e

    def load_recipes_and_training(self, force_refresh: bool = False) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Loads recipes from the external Receptbank sheet and training types from main sheet."""
        # 1. Fetch external Receptbank
        expected_cols = [
            'Receptnamn', 'Protein_g', 'Fett_g', 'Kolhydrater_g', 'Kcal',
            'Ingredienser', 'Instruktioner',
            'is_breakfast', 'is_lunch', 'is_dinner', 'is_snack', 'is_goodie',
            'is_ready_meal', 'is_own_meal'
        ]
        
        # Check cache first
        if not force_refresh and 'recipes' in self._cache and 'training' in self._cache:
            return self._cache['recipes'], self._cache['training']
            
        try:
            if not force_refresh and 'recipes' in self._cache:
                recipes = self._cache['recipes']
            else:
                rb_sh = self.client.open_by_url(RECEPTBANK_URL)
                rb_wks = rb_sh.worksheet(RECEPTBANK_SHEET)
                rb_data = rb_wks.get_all_values()
                
                if not rb_data or len(rb_data) == 0:
                    recipes = pd.DataFrame(columns=expected_cols)
                else:
                    rb_headers = [h.strip() for h in rb_data[0]]
                    rb_rows = rb_data[1:]
                    df = pd.DataFrame(rb_rows, columns=rb_headers)
                    
                    # Standardize column mappings
                    df.columns = df.columns.astype(str).str.strip()
                    col_map = {
                        'receptnamn': 'Receptnamn',
                        'kategorier': 'Kategorier',
                        'protein': 'Protein_g',
                        'fett': 'Fett_g',
                        'kolhydrater': 'Kolhydrater_g',
                        'kcal': 'Kcal',
                        'ingredienser': 'Ingredienser',
                        'instruktioner': 'Instruktioner'
                    }
                    
                    rename_dict = {}
                    for col in df.columns:
                        lower_col = col.lower()
                        if lower_col in col_map:
                            rename_dict[col] = col_map[lower_col]
                    df.rename(columns=rename_dict, inplace=True)
                    
                    if 'Kategorier' not in df.columns:
                        df['Kategorier'] = ""
                    df['Kategorier'] = df['Kategorier'].astype(str)
                    
                    # Setup boolean flags based on categories string
                    df['is_breakfast'] = df['Kategorier'].str.contains('Frukost', case=False, na=False)
                    df['is_lunch'] = df['Kategorier'].str.contains('Lunch', case=False, na=False)
                    df['is_dinner'] = df['Kategorier'].str.contains('Middag', case=False, na=False)
                    df['is_snack'] = df['Kategorier'].str.contains('Mellanmål', case=False, na=False)
                    df['is_goodie'] = df['Kategorier'].str.contains('Övrigt', case=False, na=False) | df['Kategorier'].str.contains('Goodie', case=False, na=False)
                    df['is_ready_meal'] = df['Kategorier'].str.contains('Färdigrätt', case=False, na=False)
                    df['is_own_meal'] = df['Kategorier'].str.contains('Egenrätt|Egenrätter', case=False, regex=True, na=False)
                    
                    for col in expected_cols:
                        if col not in df.columns:
                            df[col] = None
                            
                    recipes = df
                
                # Clean numeric columns in recipes
                if not recipes.empty:
                    for col in ['Protein_g', 'Fett_g', 'Kolhydrater_g', 'Kcal']:
                        recipes[col] = pd.to_numeric(recipes[col].astype(str).str.replace(",", "."), errors='coerce').fillna(0.0)
                
                self._cache['recipes'] = recipes
        except Exception as e:
            print(f"Error fetching Receptbank: {e}")
            if 'recipes' in self._cache:
                recipes = self._cache['recipes']
            else:
                recipes = pd.DataFrame(columns=expected_cols)
            
        # 2. Fetch training types
        training = self._get_df(TRAINING_SHEET, force_refresh=force_refresh)
        if not training.empty:
            if 'Kalorier' in training.columns:
                training['Kalorier'] = pd.to_numeric(training['Kalorier'].astype(str).str.replace(",", "."), errors='coerce').fillna(0.0)
        
        self._cache['training'] = training
        return recipes, training

    def get_user_settings(self, user_id: int = 1, target_date = None) -> dict:
        """Retrieves weight, waist, and calorie targets for a specific user and date."""
        weight = 75.0
        waist = 0.0
        activity = 1.2
        weekly_loss = 0.5
        protein_kg = 2.5
        fat_kg = 0.7
        dist_breakfast = 25.0
        dist_lunch = 30.0
        dist_dinner = 30.0
        dist_snack = 15.0
        
        if target_date is None:
            target_date = date.today()
            
        if isinstance(target_date, str):
            target_date = pd.to_datetime(target_date).date()
        elif isinstance(target_date, datetime):
            target_date = target_date.date()
            
        # 1. Load Weight/Waist
        try:
            df_measures = self._get_df(MEASUREMENTS_SHEET)
            if not df_measures.empty:
                df_measures = df_measures.copy()
                df_measures['användarid'] = pd.to_numeric(df_measures['användarid'], errors='coerce').fillna(1).astype(int)
                df_measures = df_measures[df_measures['användarid'] == user_id]
                df_measures['datum'] = pd.to_datetime(df_measures['datum'], errors='coerce').dt.date
                df_measures = df_measures.dropna(subset=['datum'])
                
                # Filter to readings on or before target date
                df_measures = df_measures[df_measures['datum'] <= target_date]
                df_measures = df_measures.sort_values(by='datum')
                
                if not df_measures.empty:
                    # Latest weight
                    w_df = df_measures[df_measures['angiven_vikt'].apply(lambda x: safe_float(x)) > 0.0]
                    if not w_df.empty:
                        weight = safe_float(w_df.iloc[-1]['angiven_vikt'])
                        
                    # Latest waist
                    waist_col = 'midjemått_cm'
                    if waist_col in df_measures.columns:
                        wa_df = df_measures[df_measures[waist_col].apply(lambda x: safe_float(x)) > 0.0]
                        if not wa_df.empty:
                            waist = safe_float(wa_df.iloc[-1][waist_col])
        except Exception as e:
            print(f"Error getting user settings measurements: {e}")
            
        # 2. Load Calc Settings
        try:
            df_calc = self._get_df(CALC_SETTINGS_SHEET)
            if not df_calc.empty:
                df_calc = df_calc.copy()
                df_calc['användarid'] = pd.to_numeric(df_calc['användarid'], errors='coerce').fillna(1).astype(int)
                df_calc = df_calc[df_calc['användarid'] == user_id]
                df_calc['datum'] = pd.to_datetime(df_calc['datum'], errors='coerce').dt.date
                df_calc = df_calc.dropna(subset=['datum'])
                
                df_calc = df_calc[df_calc['datum'] <= target_date]
                df_calc = df_calc.sort_values(by='datum')
                
                if not df_calc.empty:
                    last_row = df_calc.iloc[-1]
                    activity = safe_float(last_row.get('aktivitetsnivå', 25.0), 25.0)
                    if activity < 5.0:
                        if activity <= 1.25:
                            activity = 25.0
                        elif activity <= 1.6:
                            activity = 30.0
                        else:
                            activity = 35.0
                    weekly_loss = safe_float(last_row.get('viktnedgång_kg_vecka', 0.5), 0.5)
                    protein_kg = safe_float(last_row.get('protein_g_kg', 2.5), 2.5)
                    fat_kg = safe_float(last_row.get('fett_g_kg', 0.7), 0.7)
                    
                    if 'dist_breakfast' in last_row: dist_breakfast = safe_float(last_row['dist_breakfast'], 25.0)
                    if 'dist_lunch' in last_row: dist_lunch = safe_float(last_row['dist_lunch'], 30.0)
                    if 'dist_dinner' in last_row: dist_dinner = safe_float(last_row['dist_dinner'], 30.0)
                    if 'dist_snack' in last_row: dist_snack = safe_float(last_row['dist_snack'], 15.0)
        except Exception as e:
            print(f"Error getting calculation settings: {e}")
            
        goals = calculate_macro_goals(weight, activity, weekly_loss, protein_kg, fat_kg)
        
        return {
            "weight": weight,
            "waist": waist,
            "activity": activity,
            "weekly_loss": weekly_loss,
            "protein_kg": protein_kg,
            "fat_kg": fat_kg,
            "dist_breakfast": dist_breakfast,
            "dist_lunch": dist_lunch,
            "dist_dinner": dist_dinner,
            "dist_snack": dist_snack,
            "bmr": goals['bmr'],
            "deficit": goals['deficit'],
            "target_calories": goals['target_calories'],
            "protein_goal": goals['protein_goal'],
            "fat_goal": goals['fat_goal'],
            "carb_goal": goals['carb_goal']
        }

    def save_user_settings(
        self, weight: float, waist: float, activity: float, weekly_loss: float,
        protein_kg: float, fat_kg: float, protein_goal: float = 0.0,
        fat_goal: float = 0.0, carb_goal: float = 0.0, equilibrium_calories: float = 0.0,
        calorie_goal: float = 0.0, dist_breakfast: float = 25.0, dist_lunch: float = 30.0,
        dist_dinner: float = 30.0, dist_snack: float = 15.0, user_id: int = 1
    ):
        """Saves both measurements and settings back to the spreadsheets."""
        today_str = datetime.now().strftime("%Y-%m-%d")
        
        # 1. Save Measurements
        df_measures = self._get_df(MEASUREMENTS_SHEET, force_refresh=True)
        if df_measures.empty:
            df_measures = pd.DataFrame(columns=['användarid', 'datum', 'angiven_vikt', 'midjemått_cm'])
            
        df_measures = df_measures.copy()
        df_measures['datum'] = df_measures['datum'].astype(str)
        mask_m = (df_measures['datum'] == today_str) & (pd.to_numeric(df_measures['användarid'], errors='coerce').fillna(1).astype(int) == user_id)
        
        if mask_m.any():
            df_measures.loc[mask_m, 'angiven_vikt'] = weight
            df_measures.loc[mask_m, 'midjemått_cm'] = waist
        else:
            new_row = pd.DataFrame([{
                'användarid': user_id,
                'datum': today_str,
                'angiven_vikt': weight,
                'midjemått_cm': waist
            }])
            df_measures = pd.concat([df_measures, new_row], ignore_index=True)
            
        self._save_df(MEASUREMENTS_SHEET, df_measures)
        
        # 2. Save Calculation Settings
        df_calc = self._get_df(CALC_SETTINGS_SHEET, force_refresh=True)
        if df_calc.empty:
            df_calc = pd.DataFrame(columns=[
                'användarid', 'datum', 'aktivitetsnivå', 'viktnedgång_kg_vecka',
                'protein_g_kg', 'fett_g_kg', 'makromål_protein', 'makromål_fett',
                'makromål_kolhydrat', 'kalorier_for_jämnvikt', 'kalorimål_för_viktnedgång',
                'dist_breakfast', 'dist_lunch', 'dist_dinner', 'dist_snack'
            ])
            
        df_calc = df_calc.copy()
        df_calc['datum'] = df_calc['datum'].astype(str)
        mask_c = (df_calc['datum'] == today_str) & (pd.to_numeric(df_calc['användarid'], errors='coerce').fillna(1).astype(int) == user_id)
        
        data_dict = {
            'användarid': user_id,
            'datum': today_str,
            'aktivitetsnivå': activity,
            'viktnedgång_kg_vecka': weekly_loss,
            'protein_g_kg': protein_kg,
            'fett_g_kg': fat_kg,
            'makromål_protein': protein_goal,
            'makromål_fett': fat_goal,
            'makromål_kolhydrat': carb_goal,
            'kalorier_for_jämnvikt': equilibrium_calories,
            'kalorimål_för_viktnedgång': calorie_goal,
            'dist_breakfast': dist_breakfast,
            'dist_lunch': dist_lunch,
            'dist_dinner': dist_dinner,
            'dist_snack': dist_snack
        }
        
        if mask_c.any():
            for k, v in data_dict.items():
                df_calc.loc[mask_c, k] = v
        else:
            new_row = pd.DataFrame([data_dict])
            df_calc = pd.concat([df_calc, new_row], ignore_index=True)
            
        self._save_df(CALC_SETTINGS_SHEET, df_calc)

    def get_diary(self, force_refresh: bool = False) -> pd.DataFrame:
        """Loads both meals and training logs and returns them combined."""
        df_meals = self._get_df(MEAL_LOG_SHEET, force_refresh=force_refresh)
        df_training = self._get_df(TRAINING_LOG_SHEET, force_refresh=force_refresh)
        
        expected_cols = ['Datum', 'Typ', 'Namn', 'Mängd', 'Kcal', 'Protein', 'Fett', 'Kolhydrater', 'Kategori']
        
        # Ensure correct column schemas
        for df in [df_meals, df_training]:
            if not df.empty:
                for col in ['Kcal', 'Protein', 'Fett', 'Kolhydrater', 'Mängd']:
                    if col in df.columns:
                        df[col] = pd.to_numeric(df[col].astype(str).str.replace(",", "."), errors='coerce').fillna(0.0)
                        
        dfs = [df for df in [df_meals, df_training] if not df.empty]
        if dfs:
            combined = pd.concat(dfs, ignore_index=True)
            return combined
        else:
            return pd.DataFrame(columns=expected_cols)

    def get_latest_measurement(self, user_id: int = 1) -> dict:
        """Retrieves the latest saved weight and date for the user."""
        default_res = {
            'weight': 0.0,
            'weight_date': None,
            'waist': 0.0,
            'waist_date': None,
            'date': None
        }
        try:
            df = self._get_df(MEASUREMENTS_SHEET)
            if not df.empty:
                df = df.copy()
                df['användarid'] = pd.to_numeric(df['användarid'], errors='coerce').fillna(1).astype(int)
                df = df[df['användarid'] == user_id]
                
                # Parse dates properly
                df['datum_parsed'] = pd.to_datetime(df['datum'], errors='coerce')
                df = df.dropna(subset=['datum_parsed'])
                df = df.sort_values(by='datum_parsed')
                
                if not df.empty:
                    # Latest weight row with valid weight > 0
                    weight_df = df[df['angiven_vikt'].apply(lambda x: safe_float(x)) > 0.0]
                    if not weight_df.empty:
                        last_w_row = weight_df.iloc[-1]
                        w = safe_float(last_w_row['angiven_vikt'])
                        w_date = str(last_w_row['datum'])
                    else:
                        w = 0.0
                        w_date = None

                    # Latest waist row with valid waist > 0
                    waist_col = 'midjemått_cm'
                    if waist_col in df.columns:
                        waist_df = df[df[waist_col].apply(lambda x: safe_float(x)) > 0.0]
                        if not waist_df.empty:
                            last_wa_row = waist_df.iloc[-1]
                            waist = safe_float(last_wa_row[waist_col])
                            waist_date = str(last_wa_row['datum'])
                        else:
                            waist = 0.0
                            waist_date = None
                    else:
                        waist = 0.0
                        waist_date = None

                    # Date of the absolute latest entry in the measurements table
                    latest_date = str(df.iloc[-1]['datum'])

                    return {
                        'weight': w,
                        'weight_date': w_date,
                        'waist': waist,
                        'waist_date': waist_date,
                        'date': latest_date
                    }
        except Exception as e:
            print(f"Error getting latest measurement: {e}")
            
        return default_res

    def get_daily_summary(self, target_date) -> tuple[float, float, dict, pd.DataFrame]:
        """Calculates total calorie intake, calories burned, macros, and gets daily logs."""
        df = self.get_diary()
        if df.empty:
            return 0.0, 0.0, {'Protein': 0.0, 'Fett': 0.0, 'Kolhydrater': 0.0}, pd.DataFrame()
            
        date_str = target_date.strftime("%Y-%m-%d") if hasattr(target_date, 'strftime') else str(target_date)
        
        df['Datum'] = df['Datum'].astype(str)
        daily = df[df['Datum'] == date_str]
        
        food = daily[daily['Typ'] == 'Mat']
        training = daily[daily['Typ'] == 'Träning']
        
        intake = food['Kcal'].sum()
        burned = training['Kcal'].sum()
        
        macros = {
            'Protein': food['Protein'].sum(),
            'Fett': food['Fett'].sum(),
            'Kolhydrater': food['Kolhydrater'].sum()
        }
        
        return intake, burned, macros, food

    def save_daily_logs_batch(self, target_date, log_entries: list, log_type: str = 'Mat', deleted_entries: list = None):
        """Saves a batch of daily logs to MEAL_LOG_SHEET or TRAINING_LOG_SHEET."""
        if deleted_entries is None:
            deleted_entries = []
            
        date_str = target_date.strftime("%Y-%m-%d") if hasattr(target_date, 'strftime') else str(target_date)
        target_sheet = MEAL_LOG_SHEET if log_type == 'Mat' else TRAINING_LOG_SHEET
        
        df = self._get_df(target_sheet, force_refresh=True)
        if df.empty:
            df = pd.DataFrame(columns=['Datum', 'Typ', 'Namn', 'Mängd', 'Kcal', 'Protein', 'Fett', 'Kolhydrater', 'Kategori'])
            
        df = df.copy()
        df['Datum'] = df['Datum'].astype(str)
        
        # Split into kept and today's logs
        mask = (df['Datum'] == date_str) & (df['Typ'] == log_type)
        df_kept = df[~mask]
        df_today = df[mask].copy()
        
        # Apply deletions
        if not df_today.empty and deleted_entries:
            for d in deleted_entries:
                d_name = d.get('Namn')
                d_cat = d.get('Kategori')
                if d_name:
                    df_today = df_today[~((df_today['Namn'] == d_name) & (df_today['Kategori'] == d_cat))]
                    
        # Merge new logs avoiding exact duplicates
        new_rows = []
        existing_pool = df_today[['Namn', 'Kategori']].to_dict('records') if not df_today.empty else []
        
        for entry in log_entries:
            e_name = entry.get('Namn')
            e_cat = entry.get('Kategori')
            
            match_found = False
            for i, ex in enumerate(existing_pool):
                if ex['Namn'] == e_name and ex['Kategori'] == e_cat:
                    match_found = True
                    existing_pool.pop(i)
                    break
                    
            if not match_found:
                row = entry.copy()
                row['Datum'] = date_str
                row['Typ'] = log_type
                for col in ['Namn', 'Mängd', 'Kcal', 'Protein', 'Fett', 'Kolhydrater', 'Kategori']:
                    if col not in row:
                        row[col] = 0.0 if col in ['Mängd', 'Kcal', 'Protein', 'Fett', 'Kolhydrater'] else ""
                new_rows.append(row)
                
        if new_rows:
            df_new = pd.DataFrame(new_rows)
            final_df = pd.concat([df_kept, df_today, df_new], ignore_index=True)
        else:
            final_df = pd.concat([df_kept, df_today], ignore_index=True) if not df_today.empty else df_kept
            
        self._save_df(target_sheet, final_df)

    def clear_daily_log(self, target_date, log_type: str = 'Mat'):
        """Deletes all daily logs for a specific date and type."""
        date_str = target_date.strftime("%Y-%m-%d") if hasattr(target_date, 'strftime') else str(target_date)
        target_sheet = MEAL_LOG_SHEET if log_type == 'Mat' else TRAINING_LOG_SHEET
        
        df = self._get_df(target_sheet, force_refresh=True)
        if df.empty:
            return
            
        df = df.copy()
        df['Datum'] = df['Datum'].astype(str)
        mask = (df['Datum'] == date_str) & (df['Typ'] == log_type)
        
        if mask.any():
            final_df = df[~mask]
            self._save_df(target_sheet, final_df)

    def get_weekly_diff(self, target_date) -> tuple[float, int]:
        """Calculates weekly accumulated calorie difference dynamically based on historical targets."""
        df = self.get_diary()
        if df.empty:
            return 0.0, 0
            
        df = df.copy()
        df['Datum'] = pd.to_datetime(df['Datum']).dt.date
        
        days_since_monday = target_date.weekday()
        monday = target_date - timedelta(days=days_since_monday)
        
        total_diff = 0.0
        days_counted = 0
        
        curr = monday
        while curr < target_date:
            food_logs = df[(df['Datum'] == curr) & (df['Typ'] == 'Mat')]
            daily_intake = food_logs['Kcal'].sum() if not food_logs.empty else 0.0
            
            if daily_intake > 0.0:
                settings = self.get_user_settings(target_date=curr)
                daily_target = settings.get('target_calories', 0.0)
                
                daily_diff = daily_intake - daily_target
                total_diff += daily_diff
                days_counted += 1
                
            curr += timedelta(days=1)
            
        return total_diff, days_counted

    def get_weekly_breakdown(self, target_date) -> list[dict]:
        """Returns a list of daily stats for the week of the target date, using historical targets."""
        df = self.get_diary()
        if not df.empty:
            df = df.copy()
            df['Datum'] = pd.to_datetime(df['Datum']).dt.date
            
        days_since_monday = target_date.weekday()
        monday = target_date - timedelta(days=days_since_monday)
        
        weekly_data = []
        day_names = ['Måndag', 'Tisdag', 'Onsdag', 'Torsdag', 'Fredag', 'Lördag', 'Söndag']
        
        for i in range(7):
            curr = monday + timedelta(days=i)
            
            if df.empty:
                food_logs = pd.DataFrame(columns=['Datum', 'Typ', 'Namn', 'Mängd', 'Kcal', 'Protein', 'Fett', 'Kolhydrater', 'Kategori'])
            else:
                food_logs = df[(df['Datum'] == curr) & (df['Typ'] == 'Mat')]
                
            intake = food_logs['Kcal'].sum() if not food_logs.empty else 0.0
            
            settings = self.get_user_settings(target_date=curr)
            daily_target = settings.get('target_calories', 0.0)
            
            diff = intake - daily_target
            
            weekly_data.append({
                'date': curr,
                'day_name': day_names[i],
                'intake': intake,
                'diff': diff,
                'has_data': not food_logs.empty,
                'meals': food_logs,
                'target': daily_target
            })
            
        return weekly_data