import flet as ft

# Modern Health / Nutrition Premium Colors (Emerald & Teal HSL Harmonized Scheme)
PRIMARY_COLOR = "#10b981"    # Mint Emerald Green
SECONDARY_COLOR = "#0d9488"  # Ocean Teal
ACCENT_COLOR = "#34d399"     # Light Sage
BG_COLOR = "#090d16"         # Ultra-dark Midnight Slate
CARD_BG = "#111827"          # Dark Grey-blue Slate
TEXT_PRIMARY = "#f9fafb"     # Clean White
TEXT_MUTED = "#9ca3af"       # Soft Cool Gray
BORDER_COLOR = "#1f2937"     # Dark slate borders

def get_app_theme():
    """Returns a highly polished Material 3 Theme optimized for dark mode premium layouts."""
    return ft.Theme(
        color_scheme=ft.ColorScheme(
            primary=PRIMARY_COLOR,
            primary_container=SECONDARY_COLOR,
            secondary=SECONDARY_COLOR,
            surface=CARD_BG,
            error="#f43f5e",
            on_primary=TEXT_PRIMARY,
            on_secondary=TEXT_PRIMARY,
            on_surface=TEXT_PRIMARY,
            on_surface_variant=TEXT_MUTED,
            outline=BORDER_COLOR,
        ),
        text_theme=ft.TextTheme(
            body_large=ft.TextStyle(color=TEXT_PRIMARY, size=16),
            body_medium=ft.TextStyle(color=TEXT_MUTED, size=14),
            title_large=ft.TextStyle(color=TEXT_PRIMARY, size=22, weight=ft.FontWeight.BOLD),
            title_medium=ft.TextStyle(color=TEXT_PRIMARY, size=18, weight=ft.FontWeight.W_600),
        )
    )