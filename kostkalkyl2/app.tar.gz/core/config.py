import os
import sys

# Locate the secrets.toml of the legacy KostKalkyl project dynamically
# Legacy project path: d:\Dev\personal-projects\KostKalkyl\.streamlit\secrets.toml
LEGACY_SECRETS_PATH = r"d:\Dev\personal-projects\KostKalkyl\.streamlit\secrets.toml"

# Main sheets constants
RECIPES_SHEET = 'Recept'
TRAINING_SHEET = 'Träningstyper'
MEAL_LOG_SHEET = 'Måltider_per_dag'
TRAINING_LOG_SHEET = 'Träning_per_dag'
MEASUREMENTS_SHEET = 'Dina mätvärden'
CALC_SETTINGS_SHEET = 'Inställningar kaloriberäkning'

# External spreadsheet
RECEPTBANK_URL = "https://docs.google.com/spreadsheets/d/1OL0b25sd08L1B7q-AFRsR7UJRIskZyoUS9SNZOlea_I/edit?gid=831374124#gid=831374124"
RECEPTBANK_SHEET = "Recept"

def parse_google_credentials(creds_data):
    """Parses credentials from either a dictionary or a JSON string.
    Supports both standard Google Service Account JSON format and Streamlit gsheets format.
    """
    import json
    
    if isinstance(creds_data, str):
        try:
            creds_dict = json.loads(creds_data)
        except Exception as e:
            raise ValueError(f"Ogiltigt JSON-format för inloggningsuppgifter: {e}")
    elif isinstance(creds_data, dict):
        creds_dict = creds_data
    else:
        raise ValueError("Inloggningsuppgifter måste vara en ordlista eller en JSON-sträng.")
        
    # Check if this is the Streamlit config format (contains connections.gsheets or connections)
    # E.g. {"connections": {"gsheets": {...}}}
    if "connections" in creds_dict:
        creds_dict = creds_dict.get("connections", {}).get("gsheets", {})
    elif "gsheets" in creds_dict:
        creds_dict = creds_dict.get("gsheets", {})
        
    # Verify required keys
    required_keys = ["type", "project_id", "private_key_id", "private_key", "client_email", "client_id"]
    missing = [k for k in required_keys if k not in creds_dict]
    if missing:
        raise KeyError(f"Saknade fält i Google-inloggningsuppgifter: {', '.join(missing)}")
        
    # Format private key properly (replace escaped newlines if any)
    p_key = creds_dict.get("private_key")
    if p_key and isinstance(p_key, str):
        p_key = p_key.replace("\\n", "\n")
        
    creds = {
        "type": creds_dict.get("type"),
        "project_id": creds_dict.get("project_id"),
        "private_key_id": creds_dict.get("private_key_id"),
        "private_key": p_key,
        "client_email": creds_dict.get("client_email"),
        "client_id": creds_dict.get("client_id"),
        "auth_uri": creds_dict.get("auth_uri", "https://accounts.google.com/o/oauth2/auth"),
        "token_uri": creds_dict.get("token_uri", "https://oauth2.googleapis.com/token"),
    }
    
    spreadsheet_url = creds_dict.get("spreadsheet")
    return creds, spreadsheet_url

def load_google_credentials():
    """Reads legacy streamlit secrets.toml and extracts credentials for gspread."""
    import tomllib
    
    if not os.path.exists(LEGACY_SECRETS_PATH):
        raise FileNotFoundError(f"Legacy secrets.toml not found at {LEGACY_SECRETS_PATH}")
        
    with open(LEGACY_SECRETS_PATH, "rb") as f:
        secrets = tomllib.load(f)
        
    g_cfg = secrets.get("connections", {}).get("gsheets", {})
    if not g_cfg:
        raise KeyError("connections.gsheets not found in secrets.toml")
        
    return parse_google_credentials(g_cfg)