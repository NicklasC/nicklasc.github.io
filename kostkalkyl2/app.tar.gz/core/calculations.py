def calculate_macro_goals(weight: float, activity: float, weekly_loss: float, protein_kg: float, fat_kg: float) -> dict:
    """Calculates macro and calorie goals based on settings."""
    deficit_map = {0.0: 0, 0.25: 250, 0.5: 550, 0.7: 770, 1.0: 1000}
    deficit = deficit_map.get(weekly_loss, 550)  # Fallback to 550 if unknown

    bmr = weight * activity
    target_calories = bmr - deficit
    
    protein_goal = weight * protein_kg
    fat_goal = weight * fat_kg
    
    protein_calories = protein_goal * 4
    fat_calories = fat_goal * 9
    remaining_calories = target_calories - protein_calories - fat_calories
    
    carb_goal = max(0.0, remaining_calories / 4)
    
    return {
        'bmr': bmr,
        'deficit': deficit,
        'target_calories': target_calories,
        'protein_goal': protein_goal,
        'fat_goal': fat_goal,
        'carb_goal': carb_goal
    }

def calculate_steps_calories(steps: int, kcal_per_1000: float) -> int:
    """Calculates burned calories based on step count and rate per 1000 steps."""
    if steps <= 0:
        return 0
    return int((steps / 1000.0) * kcal_per_1000)

def calculate_predicted_weight_change(calories_diff: float) -> float:
    """Calculates predicted weight change in kg based on a calorie diff (7000 kcal = 1 kg)."""
    return calories_diff / 7000.0