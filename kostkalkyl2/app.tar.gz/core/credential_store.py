import base64
import json
import os

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC


ENCRYPTED_CREDENTIALS_KEY = "google_credentials_encrypted"
LEGACY_PLAINTEXT_CREDENTIALS_KEY = "google_credentials"
SPREADSHEET_URL_KEY = "spreadsheet_url"

_FORMAT_VERSION = 1
_PBKDF2_ITERATIONS = 600_000
_MIN_PASSPHRASE_LENGTH = 12


class CredentialDecryptionError(ValueError):
    """Raised when a stored credential bundle cannot be safely unlocked."""


def validate_passphrase(passphrase: str):
    if len(passphrase) < _MIN_PASSPHRASE_LENGTH:
        raise ValueError(
            f"Lösenfrasen måste innehålla minst {_MIN_PASSPHRASE_LENGTH} tecken."
        )


def _derive_key(passphrase: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=_PBKDF2_ITERATIONS,
    )
    return base64.urlsafe_b64encode(kdf.derive(passphrase.encode("utf-8")))


def encrypt_credentials(credentials: dict, passphrase: str) -> str:
    """Serialize and encrypt service-account credentials for browser storage."""
    validate_passphrase(passphrase)
    if not isinstance(credentials, dict):
        raise TypeError("Inloggningsuppgifterna måste vara en ordlista.")

    salt = os.urandom(16)
    plaintext = json.dumps(
        credentials,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    token = Fernet(_derive_key(passphrase, salt)).encrypt(plaintext)
    return json.dumps(
        {
            "version": _FORMAT_VERSION,
            "kdf": "PBKDF2-HMAC-SHA256",
            "iterations": _PBKDF2_ITERATIONS,
            "salt": base64.urlsafe_b64encode(salt).decode("ascii"),
            "token": token.decode("ascii"),
        },
        separators=(",", ":"),
        sort_keys=True,
    )


def decrypt_credentials(encrypted_bundle: str, passphrase: str) -> dict:
    """Unlock a credential bundle without exposing decryption details."""
    try:
        payload = json.loads(encrypted_bundle)
        if (
            payload.get("version") != _FORMAT_VERSION
            or payload.get("kdf") != "PBKDF2-HMAC-SHA256"
            or payload.get("iterations") != _PBKDF2_ITERATIONS
        ):
            raise CredentialDecryptionError("Okänt format för sparade uppgifter.")

        salt = base64.urlsafe_b64decode(payload["salt"].encode("ascii"))
        token = payload["token"].encode("ascii")
        plaintext = Fernet(_derive_key(passphrase, salt)).decrypt(token)
        credentials = json.loads(plaintext.decode("utf-8"))
        if not isinstance(credentials, dict):
            raise CredentialDecryptionError("Ogiltiga sparade uppgifter.")
        return credentials
    except CredentialDecryptionError:
        raise
    except (InvalidToken, KeyError, TypeError, ValueError, UnicodeError) as error:
        raise CredentialDecryptionError(
            "Kunde inte låsa upp de sparade uppgifterna."
        ) from error
