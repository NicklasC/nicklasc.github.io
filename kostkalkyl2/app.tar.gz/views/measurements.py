import flet as ft
from src.core.theme import PRIMARY_COLOR, TEXT_PRIMARY, TEXT_MUTED, CARD_BG

class MeasurementsView(ft.Container):
    def __init__(self, shell):
        # 1. Initialize parent class first with expand=True to prevent Flet expand=None ValueError bug
        super().__init__(expand=True)
        
        self.shell = shell
        
        from datetime import date
        
        # Fetch latest measurements from sheet
        try:
            self.latest_data = shell.repo.get_latest_measurement(user_id=1)
            if not self.latest_data:
                raise ValueError("latest_data is None or empty")
        except Exception:
            self.latest_data = {
                'weight': 0.0,
                'weight_date': None,
                'waist': 0.0,
                'waist_date': None,
                'date': None
            }
            
        w_val = self.latest_data.get('weight', 0.0)
        waist_val = self.latest_data.get('waist', 0.0)
        
        # Pre-fill logic matching original app:
        # 1. Weight: Only pre-fill if recorded TODAY, otherwise empty
        # 2. Waist: Always pre-fill with latest known value (from settings)
        today_str = date.today().strftime("%Y-%m-%d")
        
        initial_weight = ""
        if self.latest_data.get('weight_date') == today_str and w_val > 0.0:
            initial_weight = f"{w_val:.1f}".replace(".", ",")
            
        initial_waist = f"{waist_val:.1f}".replace(".", ",") if waist_val > 0.0 else ""
        
        # Text fields
        self.weight_input = ft.TextField(
            label="⚖️ Dagens vikt (kg)",
            value=initial_weight,
            hint_text="t.ex. 75.5",
            keyboard_type=ft.KeyboardType.NUMBER,
            border_color="#1f2937",
            focused_border_color=PRIMARY_COLOR,
            bgcolor="#090d16",
            text_style=ft.TextStyle(color=TEXT_PRIMARY, size=16),
            width=280
        )
        
        self.waist_input = ft.TextField(
            label="📐 Midjemått (cm)",
            value=initial_waist,
            hint_text="t.ex. 85.0",
            keyboard_type=ft.KeyboardType.NUMBER,
            border_color="#1f2937",
            focused_border_color=PRIMARY_COLOR,
            bgcolor="#090d16",
            text_style=ft.TextStyle(color=TEXT_PRIMARY, size=16),
            width=280
        )
        
        self.status_text = ft.Text(size=14, color=PRIMARY_COLOR, weight=ft.FontWeight.BOLD)
        
        # Build the content tree and assign it safely
        main_content = self._build_content()
        self.content = main_content

    def handle_save(self, e):
        self.status_text.value = "Sparar mätvärden... 💾"
        self.update()
        
        # Parse inputs
        try:
            from src.repositories.google_sheets_repo import safe_float
            w = safe_float(self.weight_input.value)
            waist = safe_float(self.waist_input.value)
        except Exception:
            self.status_text.value = "⚠️ Ogiltiga värden angivna"
            self.status_text.color = ft.Colors.RED
            self.update()
            return
            
        try:
            # Save via repo
            self.shell.repo.save_user_settings(
                weight=w,
                waist=waist,
                activity=self.shell.user_settings.get("activity", 1.2),
                weekly_loss=self.shell.user_settings.get("weekly_loss", 0.5),
                protein_kg=self.shell.user_settings.get("protein_g_kg", 2.5),
                fat_kg=self.shell.user_settings.get("fett_g_kg", 0.7),
                protein_goal=self.shell.user_settings.get("protein_goal", 0.0),
                fat_goal=self.shell.user_settings.get("fat_goal", 0.0),
                carb_goal=self.shell.user_settings.get("carb_goal", 0.0),
                equilibrium_calories=self.shell.user_settings.get("bmr", 0.0),
                calorie_goal=self.shell.user_settings.get("target_calories", 0.0),
                dist_breakfast=self.shell.user_settings.get("dist_breakfast", 25.0),
                dist_lunch=self.shell.user_settings.get("dist_lunch", 30.0),
                dist_dinner=self.shell.user_settings.get("dist_dinner", 30.0),
                dist_snack=self.shell.user_settings.get("dist_snack", 15.0),
                user_id=1
            )
            
            self.status_text.value = "✅ Mätvärden sparade i Google Sheets!"
            self.status_text.color = PRIMARY_COLOR
            
            # Reload fresh settings in shell
            self.shell.sync_data()
        except Exception as ex:
            self.status_text.value = f"⚠️ Misslyckades att spara: {ex}"
            self.status_text.color = ft.Colors.RED
            
        self.update()

    def _build_content(self):
        # Show latest measurement if available
        latest_card = ft.Container(visible=False)
        w = self.latest_data.get('weight', 0.0)
        waist = self.latest_data.get('waist', 0.0)
        w_dt = self.latest_data.get('weight_date', '')
        waist_dt = self.latest_data.get('waist_date', '')
        
        if w > 0 or waist > 0:
            latest_card = ft.Container(
                content=ft.Column([
                    ft.Text("📅 Senaste mätningar", size=13, weight=ft.FontWeight.BOLD, color=TEXT_MUTED),
                    ft.Row([
                        # Weight
                        ft.Column([
                            ft.Text("Vikt", size=10, color=TEXT_MUTED, weight=ft.FontWeight.BOLD),
                            ft.Row([
                                ft.Text(f"{w:.1f}", size=20, weight=ft.FontWeight.BOLD, color=TEXT_PRIMARY),
                                ft.Text("KG", size=11, color=TEXT_MUTED)
                            ], alignment=ft.MainAxisAlignment.START, vertical_alignment=ft.CrossAxisAlignment.END, spacing=2),
                            ft.Text(f"Registrerad {w_dt if w_dt else '-'}", size=9, color=TEXT_MUTED)
                        ], expand=True, spacing=2),
                        
                        # Waist
                        ft.Column([
                            ft.Text("Midjemått", size=10, color=TEXT_MUTED, weight=ft.FontWeight.BOLD),
                            ft.Row([
                                ft.Text(f"{waist:.0f}" if waist > 0 else "-", size=20, weight=ft.FontWeight.BOLD, color=TEXT_PRIMARY),
                                ft.Text("CM", size=11, color=TEXT_MUTED)
                            ], alignment=ft.MainAxisAlignment.START, vertical_alignment=ft.CrossAxisAlignment.END, spacing=2),
                            ft.Text(f"Registrerad {waist_dt if waist_dt else '-'}", size=9, color=TEXT_MUTED)
                        ], expand=True, spacing=2)
                    ], spacing=16)
                ], spacing=8),
                padding=16,
                bgcolor=CARD_BG,
                border_radius=12,
                border=ft.Border(
                    top=ft.BorderSide(1, "#1f2937"),
                    bottom=ft.BorderSide(1, "#1f2937"),
                    left=ft.BorderSide(1, "#1f2937"),
                    right=ft.BorderSide(1, "#1f2937")
                ),
                width=320
            )
            
        return ft.Column(
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=20,
            scroll=ft.ScrollMode.AUTO,
            expand=True,
            controls=[
                ft.Container(
                    content=ft.Column(
                        controls=[
                            ft.Text("📏 Registrera mätvärden", size=24, weight=ft.FontWeight.BOLD, color=TEXT_PRIMARY),
                            ft.Text("Uppdatera din dagliga vikt och midjemått.", size=14, color=TEXT_MUTED),
                        ]
                    ),
                    padding=ft.Padding(0, 10, 0, 10),
                    alignment=ft.alignment.Alignment(-1, 0)
                ),
                latest_card,
                ft.Container(
                    content=ft.Column(
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=16,
                        controls=[
                            self.weight_input,
                            self.waist_input,
                            self.status_text,
                            ft.ElevatedButton(
                                content=ft.Row([
                                    ft.Icon(ft.Icons.SAVE, color=TEXT_PRIMARY, size=18),
                                    ft.Text("Spara Mätvärden", color=TEXT_PRIMARY, weight=ft.FontWeight.BOLD)
                                ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
                                bgcolor=PRIMARY_COLOR,
                                color=TEXT_PRIMARY,
                                on_click=self.handle_save,
                                style=ft.ButtonStyle(
                                    shape=ft.RoundedRectangleBorder(radius=8),
                                    padding=16
                                ),
                                width=280
                            )
                        ]
                    ),
                    padding=24,
                    bgcolor=CARD_BG,
                    border_radius=12,
                    border=ft.Border(
                        top=ft.BorderSide(1, "#1f2937"),
                        bottom=ft.BorderSide(1, "#1f2937"),
                        left=ft.BorderSide(1, "#1f2937"),
                        right=ft.BorderSide(1, "#1f2937")
                    ),
                    width=320,
                )
            ]
        )