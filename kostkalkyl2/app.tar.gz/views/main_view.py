import flet as ft
from datetime import date, timedelta
from src.core.theme import BG_COLOR, PRIMARY_COLOR, TEXT_PRIMARY, TEXT_MUTED, CARD_BG

class MainView(ft.Container):
    def __init__(self, repo):
        super().__init__()
        self.repo = repo
        self.selected_date = date.today()
        
        # Shared data cache loaded from repo
        self.recipes = None
        self.training_types = None
        self.user_settings = None
        
        # Loader / Spinner control
        self.sync_button = ft.IconButton(
            icon=ft.Icons.SYNC,
            icon_color=PRIMARY_COLOR,
            on_click=self.handle_sync,
            tooltip="Synkronisera data med Google Sheets"
        )
        self.loader = ft.ProgressRing(width=20, height=20, stroke_width=2, visible=False)
        
        # Date selector controls
        self.date_text = ft.Text(
            self.format_date(self.selected_date),
            size=18,
            weight=ft.FontWeight.BOLD,
            color=TEXT_PRIMARY
        )
        
        # View content container
        self.view_container = ft.Container(expand=True, padding=12)
        
        # Load initial data
        self.sync_data()
        
        # Build UI layout
        self.build_ui()

    def format_date(self, d: date) -> str:
        """Helper to format date cleanly in Swedish."""
        months = [
            "januari", "februari", "mars", "april", "maj", "juni",
            "juli", "augusti", "september", "oktober", "november", "december"
        ]
        days = ["Måndag", "Tisdag", "Onsdag", "Torsdag", "Fredag", "Lördag", "Söndag"]
        return f"{days[d.weekday()]} {d.day} {months[d.month-1]}"

    def sync_data(self, force_refresh: bool = False):
        """Fetches fresh data from Google Sheets."""
        try:
            if force_refresh:
                self.repo._cache.clear()
            self.recipes, self.training_types = self.repo.load_recipes_and_training(force_refresh=force_refresh)
            self.user_settings = self.repo.get_user_settings(user_id=1, target_date=self.selected_date)
        except Exception as e:
            print(f"Error syncing data in MainView: {e}")

    def handle_sync(self, e):
        self.sync_button.visible = False
        self.loader.visible = True
        self.update()
        
        # Live reload forcing a full remote sheets refresh
        self.sync_data(force_refresh=True)
        self.render_active_tab()
        
        self.sync_button.visible = True
        self.loader.visible = False
        self.update()

    def change_date(self, delta: int):
        self.selected_date += timedelta(days=delta)
        self.date_text.value = self.format_date(self.selected_date)
        self.user_settings = self.repo.get_user_settings(user_id=1, target_date=self.selected_date)
        self.render_active_tab()
        self.update()

    def show_date_picker(self, e):
        """Displays Flet's system DatePicker."""
        def handle_picker_change(e_picker):
            picker_date = datetime_to_date(e_picker.control.value)
            if picker_date:
                self.selected_date = picker_date
                self.date_text.value = self.format_date(self.selected_date)
                self.user_settings = self.repo.get_user_settings(user_id=1, target_date=self.selected_date)
                self.render_active_tab()
                self.update()

        def datetime_to_date(val) -> date:
            if not val:
                return None
            if isinstance(val, str):
                return datetime.fromisoformat(val).date()
            return val.date() if hasattr(val, 'date') else val

        date_picker = ft.DatePicker(
            value=datetime_to_date(self.selected_date) or date.today(),
            on_change=handle_picker_change
        )
        self.page.overlay.append(date_picker)
        self.page.update()
        date_picker.open()

    def render_active_tab(self):
        """Instantiates and renders the view corresponding to the active tab index."""
        idx = self.nav_bar.selected_index
        
        from src.views.measurements import MeasurementsView
        from src.views.calorie_settings import CalorieSettingsView
        from src.views.register_meal import RegisterMealView
        from src.views.register_training import RegisterTrainingView
        from src.views.calorie_report import CalorieReportView
        
        # Tabs dependency order: Måltider (0) -> Mätvärden (1) -> Träning (2) -> Mål (3) -> Rapport (4)
        if idx == 0:
            view = RegisterMealView(self)
        elif idx == 1:
            view = MeasurementsView(self)
        elif idx == 2:
            view = RegisterTrainingView(self)
        elif idx == 3:
            view = CalorieSettingsView(self)
        else:
            view = CalorieReportView(self)
            
        self.view_container.content = view
        
        # Only call update if MainView is already mounted on the active page session
        try:
            if self.page:
                self.view_container.update()
        except RuntimeError:
            pass

    def handle_nav_change(self, e):
        self.render_active_tab()

    async def handle_logout(self):
        """Clears client credentials and resets app to SetupView."""
        await self.page.shared_preferences.remove("google_credentials")
        await self.page.shared_preferences.remove("spreadsheet_url")
        self.page.clean()
        
        from src.views.setup_view import SetupView
        
        def on_setup_success(new_repo):
            self.page.clean()
            self.page.add(MainView(repo=new_repo))
            
        self.page.add(SetupView(on_success=on_setup_success))

    def build_ui(self):
        # Header Controls
        header = ft.Container(
            content=ft.Row(
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.IconButton(ft.Icons.CHEVRON_LEFT, icon_color=TEXT_PRIMARY, on_click=lambda e: self.change_date(-1)),
                    ft.GestureDetector(
                        content=ft.Row(
                            spacing=6,
                            controls=[
                                ft.Icon(ft.Icons.CALENDAR_MONTH, color=PRIMARY_COLOR, size=18),
                                self.date_text,
                            ]
                        ),
                        on_tap=self.show_date_picker
                    ),
                    ft.Row(
                        spacing=4,
                        controls=[
                            self.sync_button,
                            self.loader
                        ]
                    ),
                    ft.IconButton(ft.Icons.CHEVRON_RIGHT, icon_color=TEXT_PRIMARY, on_click=lambda e: self.change_date(1)),
                ]
            ),
            padding=ft.Padding(12, 16, 12, 16),
            bgcolor=CARD_BG,
            border=ft.Border(bottom=ft.BorderSide(1, "#1f2937"))
        )
        
        # Navigation Bar matching exact specified order
        self.nav_bar = ft.NavigationBar(
            selected_index=0,
            on_change=self.handle_nav_change,
            bgcolor=CARD_BG,
            destinations=[
                ft.NavigationBarDestination(icon=ft.Icons.RESTAURANT, label="Måltider"),
                ft.NavigationBarDestination(icon=ft.Icons.STRAIGHTEN, label="Mätvärden"),
                ft.NavigationBarDestination(icon=ft.Icons.FITNESS_CENTER, label="Träning"),
                ft.NavigationBarDestination(icon=ft.Icons.SETTINGS, label="Mål"),
                ft.NavigationBarDestination(icon=ft.Icons.ANALYTICS, label="Rapport"),
            ]
        )
        
        # Master Layout Column
        main_column = ft.Column(
            spacing=0,
            expand=True,
            controls=[
                header,
                self.view_container,
                self.nav_bar
            ]
        )
        
        self.content = main_column
        self.expand = True
        self.width = 410
        self.bgcolor = BG_COLOR
        self.padding = 0
        
        # Mount initial active tab
        self.render_active_tab()