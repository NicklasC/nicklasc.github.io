import flet as ft
import pandas as pd
from datetime import date
import re
from src.core.theme import PRIMARY_COLOR, TEXT_PRIMARY, TEXT_MUTED, CARD_BG
from src.repositories.google_sheets_repo import safe_float

# Mappings for Category Normalisation (Swedish UI <=> English Database)
CATEGORY_MAP = {
    'breakfast': 'Frukost',
    'lunch': 'Lunch',
    'dinner': 'Middag',
    'snack': 'Mellanmål',
    'goodie': 'Övrigt',
    'extra': 'Övrigt',
    'Frukost': 'Frukost',
    'Lunch': 'Lunch',
    'Middag': 'Middag',
    'Mellanmål': 'Mellanmål',
    'Övrigt': 'Övrigt'
}

REVERSE_CATEGORY_MAP = {
    'Frukost': 'breakfast',
    'Lunch': 'lunch',
    'Middag': 'dinner',
    'Mellanmål': 'snack',
    'Övrigt': 'goodie'
}

EMOJI_MAP = {
    'Frukost': '☕',
    'Lunch': '☀️',
    'Mellanmål': '🍇',
    'Middag': '🌙',
    'Övrigt': '🍬'
}

DIST_KEY_MAP = {
    'Frukost': 'dist_breakfast',
    'Lunch': 'dist_lunch',
    'Middag': 'dist_dinner',
    'Mellanmål': 'dist_snack',
    'Övrigt': 'dist_goodie'
}

class RegisterMealView(ft.Container):
    def __init__(self, shell):
        # 1. Initialize parent class first with expand=True to prevent Flet expand=None ValueError bug
        super().__init__(expand=True)
        
        self.shell = shell
        
        # UI Selection and State
        self.active_filter = "Alla"  # "Alla", "Färdigrätt", "Egenrätt"
        self.active_sort = "Namn"    # "Senaste", "Namn", "Protein", "Fett", "Kcal"
        
        # Fixed meals structure tracks active slots per category: {'Frukost': [display_name, ...]}
        self.fixed_meals = {
            'Frukost': [None],
            'Lunch': [None],
            'Middag': [None],
            'Mellanmål': [None],
            'Övrigt': [None]
        }
        self.deleted_entries = []
        
        # Fetch configurations from shell
        self.recipes = shell.recipes
        self.goals = shell.user_settings or {}
        
        # Primary container layout
        self.main_column = ft.Column(
            spacing=16,
            scroll=ft.ScrollMode.AUTO,
            expand=True
        )
        self.content = self.main_column
        
        self.status_text = ft.Text(size=14, color=PRIMARY_COLOR, weight=ft.FontWeight.BOLD)
        
        # Trigger initial data loads
        self.load_daily_logs()

    def get_recipe_display_string(self, row) -> str:
        """Constructs display name in format: Name (P:xx F:xx K:xx C:xx)."""
        name = str(row['Receptnamn'])
        p = safe_float(row['Protein_g'])
        f = safe_float(row['Fett_g'])
        c = safe_float(row['Kolhydrater_g'])
        kcal = safe_float(row['Kcal'])
        if kcal == 0 and (p > 0 or f > 0 or c > 0):
            kcal = p * 4 + f * 9 + c * 4
        return f"{name} (P:{p:.0f} F:{f:.0f} K:{c:.0f} C:{kcal:.0f})"

    def get_macros_from_display(self, display_name: str) -> dict:
        """Parses macros from display string or looks up in recipes DataFrame."""
        if not display_name or display_name in ("Inget registrerat", "--- Övriga måltider ---"):
            return {'p': 0.0, 'f': 0.0, 'c': 0.0, 'kcal': 0.0}
            
        # Match by name in recipes dataframe first (most accurate)
        name = display_name.split(" (")[0]
        match_df = self.recipes[self.recipes['Receptnamn'] == name] if self.recipes is not None and not self.recipes.empty else pd.DataFrame()
        
        if not match_df.empty:
            row = match_df.iloc[0]
            p = safe_float(row['Protein_g'])
            f = safe_float(row['Fett_g'])
            c = safe_float(row['Kolhydrater_g'])
            kcal = safe_float(row['Kcal'])
            if kcal == 0:
                kcal = p * 4 + f * 9 + c * 4
            return {'p': p, 'f': f, 'c': c, 'kcal': kcal}
            
        # Fallback parsing directly from display text using regex
        p, f, c, kcal = 0.0, 0.0, 0.0, 0.0
        try:
            match = re.search(r"\(P:([\d\.]+) F:([\d\.]+) K:([\d\.]+) C:([\d\.]+)\)", display_name)
            if match:
                p = float(match.group(1))
                f = float(match.group(2))
                c = float(match.group(3))
                kcal = float(match.group(4))
        except Exception:
            pass
            
        return {'p': p, 'f': f, 'c': c, 'kcal': kcal}

    def load_daily_logs(self):
        """Loads already logged meals for the date from Google Sheets and maps them to categories."""
        try:
            _, _, _, daily_meals = self.shell.repo.get_daily_summary(self.shell.selected_date)
            
            # Reset local state slots
            self.fixed_meals = {
                'Frukost': [],
                'Lunch': [],
                'Middag': [],
                'Mellanmål': [],
                'Övrigt': []
            }
            self.deleted_entries = []
            
            if not daily_meals.empty:
                for _, row in daily_meals.iterrows():
                    name = str(row['Namn'])
                    cat_db = str(row['Kategori'])
                    cat = CATEGORY_MAP.get(cat_db, 'Övrigt')
                    
                    # Try matching recipe for full display info
                    match_df = self.recipes[self.recipes['Receptnamn'] == name] if self.recipes is not None and not self.recipes.empty else pd.DataFrame()
                    if not match_df.empty:
                        display_name = self.get_recipe_display_string(match_df.iloc[0])
                    else:
                        p = safe_float(row.get('Protein', 0.0))
                        f = safe_float(row.get('Fett', 0.0))
                        c = safe_float(row.get('Kolhydrater', 0.0))
                        kcal = safe_float(row.get('Kcal', 0.0))
                        if kcal == 0 and (p > 0 or f > 0 or c > 0):
                            kcal = p * 4 + f * 9 + c * 4
                        display_name = f"{name} (P:{p:.0f} F:{f:.0f} K:{c:.0f} C:{kcal:.0f})"
                        
                    self.fixed_meals[cat].append(display_name)
                    
            # Ensure each category has at least one dropdown slot showing
            for cat in self.fixed_meals:
                if not self.fixed_meals[cat]:
                    self.fixed_meals[cat] = [None]
                    
            # Populate UI elements
            self.build_content_tree()
        except Exception as e:
            print(f"Error loading daily meal logs: {e}")

    def get_dropdown_options(self, category: str) -> list[ft.dropdown.Option]:
        """Filters, sorts and returns options list for the category Dropdown."""
        if self.recipes is None or self.recipes.empty:
            return [ft.dropdown.Option("Inget registrerat")]
            
        df = self.recipes.copy()
        col_name = {
            'Frukost': 'is_breakfast',
            'Lunch': 'is_lunch',
            'Middag': 'is_dinner',
            'Mellanmål': 'is_snack',
            'Övrigt': 'is_goodie'
        }.get(category)
        
        # 1. Apply active property filters
        if self.active_filter == "Färdigrätt":
            if category in ['Lunch', 'Middag']:
                df = df[df['is_ready_meal'] == True]
            else:
                if col_name and col_name in df.columns:
                    df = df[(df[col_name] == True) & (df['is_ready_meal'] == True)]
        elif self.active_filter == "Egenrätt":
            if category in ['Lunch', 'Middag']:
                df = df[df['is_own_meal'] == True]
            else:
                if col_name and col_name in df.columns:
                    df = df[(df[col_name] == True) & (df['is_own_meal'] == True)]
        else:
            if col_name and col_name in df.columns:
                df = df[df[col_name] == True]
                
        # 2. Apply active sorts
        if self.active_sort == "Namn":
            df = df.sort_values(by='Receptnamn')
        elif self.active_sort == "Protein":
            df = df.sort_values(by='Protein_g', ascending=False)
        elif self.active_sort == "Fett":
            df = df.sort_values(by='Fett_g', ascending=False)
        elif self.active_sort == "Kcal":
            df = df.sort_values(by='Kcal', ascending=False)
            
        options_list = [self.get_recipe_display_string(row) for _, row in df.iterrows()]
        
        # 3. Special Sort logic: Senaste (Prepends the 5 most recently logged unique meals)
        if self.active_sort == "Senaste":
            recent_displays = []
            try:
                diary_df = self.shell.repo.get_diary()
                if not diary_df.empty:
                    diary_df = diary_df[diary_df['Typ'] == 'Mat'].copy()
                    diary_df['Datum_parsed'] = pd.to_datetime(diary_df['Datum'], errors='coerce')
                    diary_df = diary_df.sort_values(by='Datum_parsed', ascending=False)
                    
                    cat_diary = diary_df[diary_df['Kategori'] == REVERSE_CATEGORY_MAP.get(category, 'goodie')]
                    for _, r in cat_diary.iterrows():
                        r_name = str(r['Namn'])
                        match_rec = self.recipes[self.recipes['Receptnamn'] == r_name] if not self.recipes.empty else pd.DataFrame()
                        if not match_rec.empty:
                            display_str = self.get_recipe_display_string(match_rec.iloc[0])
                        else:
                            p = safe_float(r.get('Protein', 0.0))
                            f = safe_float(r.get('Fett', 0.0))
                            c = safe_float(r.get('Kolhydrater', 0.0))
                            kcal = safe_float(r.get('Kcal', 0.0))
                            if kcal == 0 and (p > 0 or f > 0 or c > 0):
                                kcal = p * 4 + f * 9 + c * 4
                            display_str = f"{r_name} (P:{p:.0f} F:{f:.0f} K:{c:.0f} C:{kcal:.0f})"
                            
                        if display_str not in recent_displays:
                            recent_displays.append(display_str)
                            if len(recent_displays) >= 5:
                                break
            except Exception as e:
                print(f"Error fetching latest meals for sort: {e}")
                
            # Keep recent items only if they respect active filter
            available_recent = [x for x in recent_displays if x in options_list]
            remaining_options = [x for x in options_list if x not in available_recent]
            
            final_options = ["Inget registrerat"] + available_recent
            if available_recent:
                final_options.append("--- Övriga måltider ---")
            final_options.extend(remaining_options)
            
            return [ft.dropdown.Option(x, disabled=(x == "--- Övriga måltider ---")) for x in final_options]
            
        final_options = ["Inget registrerat"] + options_list
        return [ft.dropdown.Option(x) for x in final_options]

    def build_pill(self, label: str, is_selected: bool, on_click) -> ft.Container:
        """Helper to create polished custom modern Pill containers."""
        return ft.Container(
            content=ft.Text(
                label,
                color=TEXT_PRIMARY if is_selected else TEXT_MUTED,
                size=11,
                weight=ft.FontWeight.BOLD
            ),
            bgcolor=PRIMARY_COLOR if is_selected else "#111827",
            border=ft.Border.all(width=1, color=PRIMARY_COLOR if is_selected else "#1f2937"),
            border_radius=20,
            padding=ft.Padding(left=12, top=6, right=12, bottom=6),
            alignment=ft.Alignment(0, 0),
            on_click=on_click,
            animate=ft.Animation(150, ft.AnimationCurve.EASE_OUT)
        )

    def handle_dropdown_change(self, category: str, index: int, value: str):
        prev = self.fixed_meals[category][index]
        if prev and prev != value and prev != "Inget registrerat":
            name = prev.split(" (")[0]
            self.deleted_entries.append({
                'Namn': name,
                'Kategori': REVERSE_CATEGORY_MAP.get(category, 'goodie')
            })
            
        self.fixed_meals[category][index] = value if value not in ("Inget registrerat", "--- Övriga måltider ---") else None
        self.build_content_tree()
        try:
            self.update()
        except RuntimeError:
            pass

    def handle_delete_row(self, category: str, index: int):
        popped = self.fixed_meals[category].pop(index)
        if popped and popped != "Inget registrerat":
            name = popped.split(" (")[0]
            self.deleted_entries.append({
                'Namn': name,
                'Kategori': REVERSE_CATEGORY_MAP.get(category, 'goodie')
            })
            
        if not self.fixed_meals[category]:
            self.fixed_meals[category] = [None]
            
        self.build_content_tree()
        try:
            self.update()
        except RuntimeError:
            pass

    def handle_add_row(self, category: str):
        self.fixed_meals[category].append(None)
        self.build_content_tree()
        try:
            self.update()
        except RuntimeError:
            pass

    def handle_save_to_db(self, e):
        self.status_text.value = "Sparar till Google Sheets... 💾"
        self.status_text.color = PRIMARY_COLOR
        self.status_text.update()
        
        log_entries = []
        for category, items in self.fixed_meals.items():
            db_cat = REVERSE_CATEGORY_MAP.get(category, 'goodie')
            for item in items:
                if item and item not in ("Inget registrerat", "--- Övriga måltider ---"):
                    name = item.split(" (")[0]
                    macros = self.get_macros_from_display(item)
                    
                    log_entries.append({
                        'Namn': name,
                        'Mängd': 1.0,
                        'Kcal': macros['kcal'],
                        'Protein': macros['p'],
                        'Fett': macros['f'],
                        'Kolhydrater': macros['c'],
                        'Kategori': db_cat
                    })
                    
        try:
            self.shell.repo.clear_daily_log(self.shell.selected_date, log_type='Mat')
            self.shell.repo.save_daily_logs_batch(
                target_date=self.shell.selected_date,
                log_entries=log_entries,
                log_type='Mat',
                deleted_entries=self.deleted_entries
            )
            self.deleted_entries = []
            self.status_text.value = "✅ Måltider sparade framgångsrikt!"
            self.status_text.color = PRIMARY_COLOR
            
            # Reload fresh summaries in shell
            self.shell.sync_data()
            self.load_daily_logs()
        except Exception as ex:
            self.status_text.value = f"⚠️ Misslyckades att spara: {ex}"
            self.status_text.color = ft.Colors.RED
            
        self.status_text.update()

    def build_matrix_row(self, col1, col2, col3, col4, col5, is_header=False, is_bold=False, bg_color=None, text_colors=None) -> ft.Container:
        """Draws a pixel-perfect horizontal row inside the Bottom Macro Matrix."""
        if text_colors is None:
            text_colors = [TEXT_PRIMARY] * 5
            
        cells = [col1, col2, col3, col4, col5]
        widths = [90, 70, 70, 70, 80]
        aligns = [ft.Alignment(-1, 0), ft.Alignment(1, 0), ft.Alignment(1, 0), ft.Alignment(1, 0), ft.Alignment(1, 0)]
        
        row_controls = []
        for i, val in enumerate(cells):
            if isinstance(val, ft.Control):
                content = val
            else:
                size = 11 if is_header else (12 if is_bold else 12)
                weight = ft.FontWeight.BOLD if (is_header or is_bold) else ft.FontWeight.NORMAL
                color = text_colors[i] if not is_header else TEXT_MUTED
                content = ft.Text(val, size=size, weight=weight, color=color)
                
            row_controls.append(
                ft.Container(
                    content=content,
                    width=widths[i],
                    alignment=aligns[i]
                )
            )
            
        return ft.Container(
            content=ft.Row(controls=row_controls, spacing=0),
            bgcolor=bg_color,
            padding=ft.Padding(left=8, top=6 if not is_header else 8, right=8, bottom=6 if not is_header else 8),
            border=ft.Border(bottom=ft.BorderSide(1, "#1f2937")) if is_header else None
        )

    def build_content_tree(self):
        """Constructs the fully dynamic Flet controls and renders it cleanly."""
        self.main_column.controls.clear()
        
        # 1. Header
        header_block = ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Text("🍽️ Registrera måltider", size=22, weight=ft.FontWeight.BOLD, color=TEXT_PRIMARY),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Text("Välj recept ur listorna uppdelat per måltidstyp.", size=13, color=TEXT_MUTED)
            ]),
            padding=ft.Padding(left=0, top=4, right=0, bottom=4)
        )
        self.main_column.controls.append(header_block)
        
        # 2. Sorter & Filter Sections
        def get_filter_click(f_val):
            return lambda e: self.handle_filter_toggle(f_val)
            
        def get_sort_click(s_val):
            return lambda e: self.handle_sort_toggle(s_val)

        filter_row = ft.Row(
            spacing=8,
            controls=[
                self.build_pill("Alla", self.active_filter == "Alla", get_filter_click("Alla")),
                self.build_pill("Färdigrätt", self.active_filter == "Färdigrätt", get_filter_click("Färdigrätt")),
                self.build_pill("Egenrätt", self.active_filter == "Egenrätt", get_filter_click("Egenrätt"))
            ]
        )
        
        sort_row = ft.Row(
            spacing=6,
            scroll=ft.ScrollMode.AUTO,
            controls=[
                self.build_pill("Namn", self.active_sort == "Namn", get_sort_click("Namn")),
                self.build_pill("Senaste", self.active_sort == "Senaste", get_sort_click("Senaste")),
                self.build_pill("Protein", self.active_sort == "Protein", get_sort_click("Protein")),
                self.build_pill("Fett", self.active_sort == "Fett", get_sort_click("Fett")),
                self.build_pill("Kcal", self.active_sort == "Kcal", get_sort_click("Kcal"))
            ]
        )
        
        self.main_column.controls.append(ft.Column([
            ft.Text("🔍 Filtrera efter", size=12, weight=ft.FontWeight.W_600, color=TEXT_MUTED),
            filter_row,
            ft.Text("📊 Sortera efter", size=12, weight=ft.FontWeight.W_600, color=TEXT_MUTED),
            sort_row
        ], spacing=6))
        
        # Macro target constants
        goal_p = safe_float(self.goals.get('protein_goal', 0.0))
        goal_f = safe_float(self.goals.get('fat_goal', 0.0))
        goal_c = safe_float(self.goals.get('carb_goal', 0.0))
        goal_kcal = safe_float(self.goals.get('target_calories', 0.0))
        
        # Accumulators for bottom totals
        totals = {'p': 0.0, 'f': 0.0, 'c': 0.0, 'kcal': 0.0}
        meal_type_totals = {}
        
        # 3. Category Groups (Main Meals + Snacks/Goodies)
        categories = ['Frukost', 'Lunch', 'Mellanmål', 'Middag', 'Övrigt']
        
        for category in categories:
            emoji = EMOJI_MAP[category]
            
            # Calculate actual logged totals for this category
            act_p, act_f, act_c, act_kcal = 0.0, 0.0, 0.0, 0.0
            for item in self.fixed_meals[category]:
                if item and item not in ("Inget registrerat", "--- Övriga måltider ---"):
                    macs = self.get_macros_from_display(item)
                    act_p += macs['p']
                    act_f += macs['f']
                    act_c += macs['c']
                    act_kcal += macs['kcal']
                    
            totals['p'] += act_p
            totals['f'] += act_f
            totals['c'] += act_c
            totals['kcal'] += act_kcal
            
            meal_type_totals[category] = {'p': act_p, 'f': act_f, 'c': act_c, 'kcal': act_kcal}
            
            # Category Targets based on percentages
            pct = safe_float(self.goals.get(DIST_KEY_MAP[category], 0.0)) / 100.0
            tgt_p = goal_p * pct
            tgt_f = goal_f * pct
            tgt_c = goal_c * pct
            tgt_kcal = goal_kcal * pct
            
            # Category Title Text
            cat_title = ft.Text(f"{emoji} {category}", size=15, weight=ft.FontWeight.BOLD, color=TEXT_PRIMARY)
            
            # Category Macro tag row (Pills below category header for premium, responsive wrap)
            # Show if targets are set or actual macros have been logged
            tags_row = ft.Row(
                spacing=5,
                controls=[
                    ft.Container(
                        content=ft.Text(f"Protein: {act_p:.0f}/{tgt_p:.0f}g", size=9, color=TEXT_PRIMARY, weight=ft.FontWeight.W_600),
                        bgcolor="#1f2937", border_radius=12, padding=ft.Padding(left=6, top=3, right=6, bottom=3), border=ft.Border.all(width=1, color="#374151")
                    ),
                    ft.Container(
                        content=ft.Text(f"Fett: {act_f:.0f}/{tgt_f:.0f}g", size=9, color=TEXT_PRIMARY, weight=ft.FontWeight.W_600),
                        bgcolor="#1f2937", border_radius=12, padding=ft.Padding(left=6, top=3, right=6, bottom=3), border=ft.Border.all(width=1, color="#374151")
                    ),
                    ft.Container(
                        content=ft.Text(f"Kolhydrat: {act_c:.0f}/{tgt_c:.0f}g", size=9, color=TEXT_PRIMARY, weight=ft.FontWeight.W_600),
                        bgcolor="#1f2937", border_radius=12, padding=ft.Padding(left=6, top=3, right=6, bottom=3), border=ft.Border.all(width=1, color="#374151")
                    ),
                    ft.Container(
                        content=ft.Text(f"Kcal: {act_kcal:.0f}/{tgt_kcal:.0f}", size=9, color=PRIMARY_COLOR, weight=ft.FontWeight.BOLD),
                        bgcolor="#1f2937", border_radius=12, padding=ft.Padding(left=6, top=3, right=6, bottom=3), border=ft.Border.all(width=1, color=PRIMARY_COLOR)
                    )
                ] if (tgt_p > 0 or tgt_f > 0 or tgt_kcal != 0 or act_kcal > 0) else []
            )
            
            # Slot Dropdowns
            slot_rows = []
            options = self.get_dropdown_options(category)
            
            for idx, current_val in enumerate(self.fixed_meals[category]):
                # Create handlers using closures
                def make_change(c_cat=category, c_idx=idx):
                    return lambda e: self.handle_dropdown_change(c_cat, c_idx, e.control.value)
                    
                def make_delete(c_cat=category, c_idx=idx):
                    return lambda e: self.handle_delete_row(c_cat, c_idx)
                
                val_to_use = current_val if current_val else "Inget registrerat"
                dd_options = options.copy()
                
                # Prevent Flet ValueError if value isn't strictly in options list
                if val_to_use not in [opt.key for opt in dd_options]:
                    dd_options.append(ft.dropdown.Option(val_to_use))
                    
                dd = ft.Dropdown(
                    options=dd_options,
                    value=val_to_use,
                    expand=True,
                    border_color="#1f2937",
                    focused_border_color=PRIMARY_COLOR,
                    bgcolor="#090d16",
                    on_select=make_change(),
                    content_padding=10,
                    text_style=ft.TextStyle(size=12)
                )
                
                del_btn = ft.IconButton(
                    icon=ft.Icons.DELETE_OUTLINE,
                    icon_color=ft.Colors.RED_400,
                    icon_size=18,
                    on_click=make_delete(),
                    padding=0,
                    width=30,
                    height=30
                )
                
                slot_rows.append(ft.Row(controls=[dd, del_btn], spacing=4))
                
            # Add Row Button
            def make_add(c_cat=category):
                return lambda e: self.handle_add_row(c_cat)
                
            add_btn = ft.TextButton(
                content=ft.Row([
                    ft.Icon(ft.Icons.ADD, color=PRIMARY_COLOR, size=15),
                    ft.Text("Lägg till livsmedel", color=PRIMARY_COLOR, weight=ft.FontWeight.BOLD, size=12)
                ], spacing=4),
                on_click=make_add()
            )
            
            # Group into a card container
            cat_card = ft.Container(
                content=ft.Column([
                    cat_title,
                    tags_row,
                    ft.Column(controls=slot_rows, spacing=8),
                    add_btn
                ], spacing=10),
                padding=12,
                bgcolor=CARD_BG,
                border_radius=12,
                border=ft.Border.all(width=1, color="#1f2937")
            )
            self.main_column.controls.append(cat_card)
            
        # 4. Bottom Macro Matrix
        matrix_rows = []
        # Header Row
        matrix_rows.append(self.build_matrix_row("Måltid", "Protein", "Fett", "Kolh.", "Kcal", is_header=True))
        
        # Category breakdown rows
        for category in categories:
            emoji = EMOJI_MAP[category]
            m_totals = meal_type_totals[category]
            pct = safe_float(self.goals.get(DIST_KEY_MAP[category], 0.0)) / 100.0
            
            # Only render if category has macros logged OR a target distribution exists
            if m_totals['kcal'] > 0 or pct > 0:
                matrix_rows.append(self.build_matrix_row(
                    f"{emoji} {category[:8]}",
                    f"{m_totals['p']:.0f}g",
                    f"{m_totals['f']:.0f}g",
                    f"{m_totals['c']:.0f}g",
                    f"{m_totals['kcal']:.0f} kcal",
                    text_colors=[TEXT_PRIMARY, TEXT_MUTED, TEXT_MUTED, TEXT_MUTED, TEXT_MUTED]
                ))
                
        # Static Summary rows
        matrix_rows.append(self.build_matrix_row(
            "📊 Totalt",
            f"{totals['p']:.0f}g",
            f"{totals['f']:.0f}g",
            f"{totals['c']:.0f}g",
            f"{totals['kcal']:.0f} kcal",
            is_bold=True,
            bg_color="#1f2937"
        ))
        
        matrix_rows.append(self.build_matrix_row(
            "🎯 Mål",
            f"{goal_p:.0f}g",
            f"{goal_f:.0f}g",
            f"{goal_c:.0f}g",
            f"{goal_kcal:.0f} kcal",
            text_colors=[TEXT_MUTED] * 5
        ))
        
        # Diff row color mapping
        diff_p = totals['p'] - goal_p
        diff_f = totals['f'] - goal_f
        diff_c = totals['c'] - goal_c
        diff_kcal = totals['kcal'] - goal_kcal
        
        # Protein: Over is positive (Emerald/Green), Under is warning (Orange)
        sign_p = "+" if diff_p > 0 else ""
        col_p = PRIMARY_COLOR if diff_p >= 0 else ft.Colors.ORANGE_400
        
        # Fat & Kcal: Under is positive, Over is limit warning (Red)
        sign_f = "+" if diff_f > 0 else ""
        col_f = PRIMARY_COLOR if diff_f <= 0 else ft.Colors.RED_400
        
        sign_kcal = "+" if diff_kcal > 0 else ""
        col_kcal = PRIMARY_COLOR if diff_kcal <= 0 else ft.Colors.RED_400
        
        # Carbs: Neutral
        sign_c = "+" if diff_c > 0 else ""
        
        matrix_rows.append(self.build_matrix_row(
            "⚖️ Diff",
            f"{sign_p}{diff_p:.0f}g",
            f"{sign_f}{diff_f:.0f}g",
            f"{sign_c}{diff_c:.0f}g",
            f"{sign_kcal}{diff_kcal:.0f} kcal",
            is_bold=True,
            bg_color="#111827",
            text_colors=[TEXT_PRIMARY, col_p, col_f, TEXT_PRIMARY, col_kcal]
        ))
        
        matrix_block = ft.Container(
            content=ft.Column(controls=matrix_rows, spacing=0),
            bgcolor=CARD_BG,
            border_radius=12,
            border=ft.Border.all(width=1, color="#1f2937"),
            padding=4
        )
        
        self.main_column.controls.append(ft.Column([
            ft.Text("📈 Dagöversikt: Makro per måltid", size=13, weight=ft.FontWeight.BOLD, color=TEXT_PRIMARY),
            matrix_block
        ], spacing=6))
        
        # 5. Save Button
        save_btn = ft.ElevatedButton(
            content=ft.Row([
                ft.Icon(ft.Icons.SAVE, color=TEXT_PRIMARY, size=18),
                ft.Text("Spara Registrering i Sheets", color=TEXT_PRIMARY, weight=ft.FontWeight.BOLD)
            ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
            bgcolor=PRIMARY_COLOR,
            color=TEXT_PRIMARY,
            on_click=self.handle_save_to_db,
            style=ft.ButtonStyle(
                shape=ft.RoundedRectangleBorder(radius=8),
                padding=14
            ),
            width=360
        )
        
        self.main_column.controls.append(ft.Column([
            self.status_text,
            save_btn
        ], spacing=8, horizontal_alignment=ft.CrossAxisAlignment.CENTER))

    def handle_filter_toggle(self, filter_val: str):
        self.active_filter = filter_val
        self.build_content_tree()
        try:
            self.update()
        except RuntimeError:
            pass

    def handle_sort_toggle(self, sort_val: str):
        self.active_sort = sort_val
        self.build_content_tree()
        try:
            self.update()
        except RuntimeError:
            pass