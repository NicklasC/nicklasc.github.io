import flet as ft
import re
from src.core.theme import PRIMARY_COLOR, TEXT_PRIMARY, TEXT_MUTED, CARD_BG
from src.repositories.google_sheets_repo import safe_float
from src.core.calculations import calculate_steps_calories

class RegisterTrainingView(ft.Container):
    def __init__(self, shell):
        # 1. Initialize parent class first with expand=True to prevent Flet expand=None ValueError bug
        super().__init__(expand=True)
        
        self.shell = shell
        
        # Local state
        self.steps_today = 0
        self.step_goal = 10000
        self.kcal_per_1000 = 40
        self.training_sessions = [None]
        
        # Load training options
        self.training_df = shell.training_types
        
        # Inputs
        self.steps_input = ft.TextField(
            label="Antal steg idag",
            value="0",
            keyboard_type=ft.KeyboardType.NUMBER,
            width=320,
            border_color="#1f2937",
            focused_border_color=PRIMARY_COLOR,
            bgcolor="#090d16",
            text_style=ft.TextStyle(color=TEXT_PRIMARY, size=16),
            on_change=self.recalculate
        )
        
        self.goal_input = ft.TextField(
            label="Stegmål",
            value="10000",
            keyboard_type=ft.KeyboardType.NUMBER,
            width=320,
            border_color="#1f2937",
            focused_border_color=PRIMARY_COLOR,
            bgcolor="#090d16",
            text_style=ft.TextStyle(color=TEXT_PRIMARY, size=16),
            on_change=self.recalculate
        )
        
        self.rate_input = ft.TextField(
            label="KCAL per 1000 steg",
            value="40",
            keyboard_type=ft.KeyboardType.NUMBER,
            width=320,
            border_color="#1f2937",
            focused_border_color=PRIMARY_COLOR,
            bgcolor="#090d16",
            text_style=ft.TextStyle(color=TEXT_PRIMARY, size=16),
            on_change=self.recalculate
        )
        
        self.burn_summary = ft.Column()
        self.status_text = ft.Text(size=14, color=PRIMARY_COLOR, weight=ft.FontWeight.BOLD)
        
        # Primary container layout
        self.main_column = ft.Column(
            spacing=16,
            scroll=ft.ScrollMode.AUTO,
            expand=True
        )
        self.content = self.main_column
        
        # Load logs and render initial tree
        self.load_daily_logs()

    def get_dropdown_options(self) -> list[ft.dropdown.Option]:
        """Gets options list for the training Dropdown."""
        options = [ft.dropdown.Option("Ingen aktivitet")]
        if self.training_df is not None and not self.training_df.empty:
            for _, row in self.training_df.iterrows():
                options.append(ft.dropdown.Option(
                    f"🏋️ {row['Träningstyp']} ({safe_float(row['Kalorier']):.0f} kcal)"
                ))
        return options

    def load_daily_logs(self):
        """Loads saved logs for the current date."""
        try:
            diary = self.shell.repo.get_diary()
            
            # Reset values
            steps_val = 0
            self.training_sessions = []
            
            if not diary.empty:
                diary['Datum'] = diary['Datum'].astype(str)
                date_str = self.shell.selected_date.strftime("%Y-%m-%d")
                todays_logs = diary[(diary['Datum'] == date_str) & (diary['Typ'] == 'Träning')]
                
                for _, row in todays_logs.iterrows():
                    name = str(row['Namn'])
                    if name == "Steg":
                        steps_val = int(safe_float(row['Mängd']))
                    else:
                        # Match training option
                        if self.training_df is not None and not self.training_df.empty:
                            match = self.training_df[self.training_df['Träningstyp'] == name]
                            if not match.empty:
                                display_str = f"🏋️ {name} ({safe_float(match.iloc[0]['Kalorier']):.0f} kcal)"
                            else:
                                kcal = safe_float(row.get('Kcal', 0.0))
                                display_str = f"🏋️ {name} ({kcal:.0f} kcal)"
                        else:
                            kcal = safe_float(row.get('Kcal', 0.0))
                            display_str = f"🏋️ {name} ({kcal:.0f} kcal)"
                        
                        self.training_sessions.append(display_str)
                        
            self.steps_input.value = str(steps_val)
            if not self.training_sessions:
                self.training_sessions = [None]
                
            self.build_content_tree()
        except Exception as e:
            print(f"Error loading daily training logs: {e}")

    def recalculate(self, e):
        steps = int(safe_float(self.steps_input.value))
        goal = int(safe_float(self.goal_input.value, 10000))
        rate = safe_float(self.rate_input.value, 40)
        
        steps_kcal = calculate_steps_calories(steps, rate)
        
        # Calculate training sessions calories
        extra_kcal = 0.0
        details_controls = []
        
        def get_kcal_from_display(display):
            if not display or display == "Ingen aktivitet":
                return 0.0, ""
            try:
                match = re.search(r"🏋️ (.*) \(([\d\.]+) kcal\)", display)
                if match:
                    name = match.group(1).strip()
                    kcal = float(match.group(2))
                    return kcal, name
            except Exception:
                pass
            return 0.0, ""
            
        for sess in self.training_sessions:
            if sess and sess != "Ingen aktivitet":
                kcal, name = get_kcal_from_display(sess)
                extra_kcal += kcal
                if name:
                    details_controls.append(
                        ft.Row([
                            ft.Text(f"🏋️ {name}:", size=12, color=TEXT_MUTED),
                            ft.Text(f"{kcal:.0f} kcal", size=12, weight=ft.FontWeight.W_600, color=TEXT_PRIMARY)
                        ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN, width=320)
                    )
                    
        total_burn = steps_kcal + extra_kcal
        
        # Step progress indicator
        prog_val = min(steps / goal, 1.0) if goal > 0 else 0.0
        prog_color = PRIMARY_COLOR if steps >= goal else ft.Colors.AMBER_400
        
        summary_controls = [
            ft.Text(f"👟 Steg förbränning: {steps_kcal:.0f} kcal", size=14, color=TEXT_PRIMARY),
            ft.ProgressBar(value=prog_val, color=prog_color, bgcolor="#1f2937", width=320),
            ft.Row([
                ft.Text(f"Mål framsteg: {prog_val*100:.0f}%", size=11, color=TEXT_MUTED),
                ft.Text(f"{steps:,} / {goal:,} steg", size=11, color=TEXT_MUTED)
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN, width=320),
            ft.Divider(color="#1f2937")
        ]
        
        # Append dynamic workout items
        if details_controls:
            summary_controls.extend(details_controls)
            summary_controls.append(ft.Divider(color="#1f2937"))
            
        summary_controls.append(
            ft.Row([
                ft.Text("🔥 Total dagsförbränning:", size=16, color=TEXT_PRIMARY),
                ft.Text(f"{total_burn:.0f} kcal", size=16, weight=ft.FontWeight.BOLD, color=PRIMARY_COLOR)
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN, width=320)
        )
        
        self.burn_summary.controls = summary_controls
        
        try:
            self.burn_summary.update()
        except RuntimeError:
            pass

    def build_content_tree(self):
        self.main_column.controls.clear()
        
        # 1. Header
        header_block = ft.Container(
            content=ft.Column([
                ft.Text("🏋️ Registrera träning & steg", size=24, weight=ft.FontWeight.BOLD, color=TEXT_PRIMARY),
                ft.Text("Mät din dagsförbränning via steg och träningspass.", size=14, color=TEXT_MUTED)
            ]),
            padding=ft.Padding(0, 10, 0, 10)
        )
        self.main_column.controls.append(header_block)
        
        # 2. Workout rows
        workout_controls = []
        options = self.get_dropdown_options()
        
        for idx, current_val in enumerate(self.training_sessions):
            # Closures for change and delete
            def make_change(c_idx=idx):
                return lambda e: self.handle_dropdown_change(c_idx, e.control.value)
                
            def make_delete(c_idx=idx):
                return lambda e: self.handle_delete_row(c_idx)
                
            val_to_use = current_val if current_val else "Ingen aktivitet"
            dd_options = options.copy()
            
            # Prevent Flet ValueError if value isn't in options list
            if val_to_use not in [opt.key for opt in dd_options]:
                dd_options.append(ft.dropdown.Option(val_to_use))
                
            dd = ft.Dropdown(
                options=dd_options,
                value=val_to_use,
                expand=True,
                border_color="#1f2937",
                focused_border_color=PRIMARY_COLOR,
                bgcolor="#090d16",
                on_select=make_change(),
                content_padding=10
            )
            
            del_btn = ft.IconButton(
                icon=ft.Icons.DELETE_OUTLINE,
                icon_color=ft.Colors.RED_400,
                icon_size=18,
                on_click=make_delete()
            )
            
            workout_controls.append(ft.Row(controls=[dd, del_btn], spacing=4))
            
        add_btn = ft.TextButton(
            content=ft.Row([
                ft.Icon(ft.Icons.ADD, color=PRIMARY_COLOR, size=15),
                ft.Text("Lägg till aktivitet", color=PRIMARY_COLOR, weight=ft.FontWeight.BOLD, size=12)
            ], spacing=4),
            on_click=self.handle_add_row
        )
        
        # 3. Card panel containing input and session dropdowns
        card_content = ft.Container(
            content=ft.Column(
                spacing=16,
                controls=[
                    self.steps_input,
                    self.goal_input,
                    self.rate_input,
                    ft.Divider(color="#1f2937"),
                    ft.Text("🏋️ Träningspass & Aktiviteter", size=15, weight=ft.FontWeight.BOLD, color=TEXT_PRIMARY),
                    ft.Column(controls=workout_controls, spacing=8),
                    add_btn,
                    ft.Divider(color="#1f2937"),
                    self.burn_summary,
                    self.status_text,
                    ft.ElevatedButton(
                        content=ft.Row([
                            ft.Icon(ft.Icons.SAVE, color=TEXT_PRIMARY, size=18),
                            ft.Text("Spara Aktivitet", color=TEXT_PRIMARY, weight=ft.FontWeight.BOLD)
                        ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
                        bgcolor=PRIMARY_COLOR,
                        color=TEXT_PRIMARY,
                        on_click=self.handle_save,
                        style=ft.ButtonStyle(
                            shape=ft.RoundedRectangleBorder(radius=8),
                            padding=16
                        ),
                        width=320
                    )
                ]
            ),
            padding=24,
            bgcolor=CARD_BG,
            border_radius=12,
            border=ft.Border(
                top=ft.BorderSide(1, "#1f2937"),
                bottom=ft.BorderSide(1, "#1f2937"),
                left=ft.BorderSide(1, "#1f2937"),
                right=ft.BorderSide(1, "#1f2937")
            ),
            width=360
        )
        
        self.main_column.controls.append(card_content)
        self.recalculate(None)

    def handle_dropdown_change(self, index: int, value: str):
        self.training_sessions[index] = value if value != "Ingen aktivitet" else None
        self.build_content_tree()
        try:
            self.update()
        except RuntimeError:
            pass

    def handle_delete_row(self, index: int):
        self.training_sessions.pop(index)
        if not self.training_sessions:
            self.training_sessions = [None]
        self.build_content_tree()
        try:
            self.update()
        except RuntimeError:
            pass

    def handle_add_row(self, e):
        self.training_sessions.append(None)
        self.build_content_tree()
        try:
            self.update()
        except RuntimeError:
            pass

    def handle_save(self, e):
        self.status_text.value = "Sparar aktivitet... 💾"
        self.status_text.color = PRIMARY_COLOR
        self.status_text.update()
        
        steps = int(safe_float(self.steps_input.value))
        rate = safe_float(self.rate_input.value, 40)
        
        log_entries = []
        
        # 1. Add steps log
        if steps > 0:
            steps_kcal = calculate_steps_calories(steps, rate)
            log_entries.append({
                'Namn': 'Steg',
                'Mängd': steps,
                'Kcal': steps_kcal,
                'Protein': 0.0,
                'Fett': 0.0,
                'Kolhydrater': 0.0,
                'Kategori': 'Steg'
            })
            
        # 2. Add dynamic training logs
        def get_kcal_from_display(display):
            if not display or display == "Ingen aktivitet":
                return 0.0, ""
            try:
                match = re.search(r"🏋️ (.*) \(([\d\.]+) kcal\)", display)
                if match:
                    name = match.group(1).strip()
                    kcal = float(match.group(2))
                    return kcal, name
            except Exception:
                pass
            return 0.0, ""
            
        for sess in self.training_sessions:
            if sess and sess != "Ingen aktivitet":
                kcal, name = get_kcal_from_display(sess)
                if name:
                    log_entries.append({
                        'Namn': name,
                        'Mängd': 1.0,
                        'Kcal': kcal,
                        'Protein': 0.0,
                        'Fett': 0.0,
                        'Kolhydrater': 0.0,
                        'Kategori': 'Träning'
                    })
                    
        try:
            self.shell.repo.clear_daily_log(self.shell.selected_date, log_type='Träning')
            if log_entries:
                self.shell.repo.save_daily_logs_batch(
                    target_date=self.shell.selected_date,
                    log_entries=log_entries,
                    log_type='Träning'
                )
            self.status_text.value = "✅ Aktivitet har sparats!"
            self.status_text.color = PRIMARY_COLOR
            self.shell.sync_data()
            self.load_daily_logs()
        except Exception as ex:
            self.status_text.value = f"⚠️ Misslyckades att spara: {ex}"
            self.status_text.color = ft.Colors.RED
            
        self.status_text.update()