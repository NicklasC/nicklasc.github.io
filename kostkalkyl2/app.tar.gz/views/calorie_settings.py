import flet as ft
from src.core.theme import PRIMARY_COLOR, TEXT_PRIMARY, TEXT_MUTED, CARD_BG
from src.repositories.google_sheets_repo import safe_float
from src.core.calculations import calculate_macro_goals

class CalorieSettingsView(ft.Container):
    def __init__(self, shell):
        # 1. Initialize parent class first with expand=True to prevent Flet expand=None ValueError bug
        super().__init__(expand=True)
        
        self.shell = shell
        
        # Load settings from shell cache
        self.settings = shell.user_settings or {}
        self.weight = self.settings.get("weight", 75.0)
        self.waist = self.settings.get("waist", 0.0)
        
        # Inputs
        activity_options = {
            25: "Stillasittande (25) - Träning 2-4ggr/v",
            30: "Måttligt aktiv (30) - Träning 4-5ggr/v",
            35: "Mycket aktiv (35) - Hård träning"
        }
        
        # Load activity safely (standardizing to float/int)
        raw_act = self.settings.get("activity", 25)
        try:
            act_val = int(float(str(raw_act)))
        except ValueError:
            act_val = 25
            
        if act_val not in activity_options:
            act_val = min(activity_options.keys(), key=lambda x: abs(x - act_val))
            
        self.activity_dd = ft.Dropdown(
            label="Livsstilsfaktor",
            options=[
                ft.dropdown.Option("25", activity_options[25]),
                ft.dropdown.Option("30", activity_options[30]),
                ft.dropdown.Option("35", activity_options[35])
            ],
            value=str(act_val),
            width=320,
            border_color="#1f2937",
            focused_border_color=PRIMARY_COLOR,
            bgcolor="#090d16",
            on_select=self.recalculate
        )
        
        self.loss_dd = ft.Dropdown(
            label="Takt för viktnedgång",
            options=[
                ft.dropdown.Option("0.0", "Jämvikt (0.0 kg/vecka)"),
                ft.dropdown.Option("0.25", "-0.25 kg/vecka (-250 kcal/dag)"),
                ft.dropdown.Option("0.5", "-0.5 kg/vecka (-550 kcal/dag)"),
                ft.dropdown.Option("0.7", "-0.7 kg/vecka (-770 kcal/dag)"),
                ft.dropdown.Option("1.0", "-1.0 kg/vecka (-1000 kcal/dag)")
            ],
            value=str(self.settings.get("weekly_loss", 0.5)),
            width=320,
            border_color="#1f2937",
            focused_border_color=PRIMARY_COLOR,
            bgcolor="#090d16",
            on_select=self.recalculate
        )
        
        self.protein_input = ft.TextField(
            label="Protein per KG kroppsvikt (g/kg)",
            value=f"{safe_float(self.settings.get('protein_kg', 2.5)):.1f}".replace(".", ","),
            keyboard_type=ft.KeyboardType.NUMBER,
            width=320,
            border_color="#1f2937",
            focused_border_color=PRIMARY_COLOR,
            bgcolor="#090d16",
            on_change=self.recalculate
        )
        
        self.fat_input = ft.TextField(
            label="Fett per KG kroppsvikt (g/kg)",
            value=f"{safe_float(self.settings.get('fat_kg', 0.7)):.1f}".replace(".", ","),
            keyboard_type=ft.KeyboardType.NUMBER,
            width=320,
            border_color="#1f2937",
            focused_border_color=PRIMARY_COLOR,
            bgcolor="#090d16",
            on_change=self.recalculate
        )
        
        # Meal distributions
        self.dist_breakfast = ft.TextField(label="Frukost (%)", value=str(int(self.settings.get("dist_breakfast", 25))), width=150, on_change=self.recalculate)
        self.dist_lunch = ft.TextField(label="Lunch (%)", value=str(int(self.settings.get("dist_lunch", 30))), width=150, on_change=self.recalculate)
        self.dist_dinner = ft.TextField(label="Middag (%)", value=str(int(self.settings.get("dist_dinner", 30))), width=150, on_change=self.recalculate)
        self.dist_snack = ft.TextField(label="Mellanmål (%)", value=str(int(self.settings.get("dist_snack", 15))), width=150, on_change=self.recalculate)
        
        # Summary metrics text
        self.summary_text = ft.Column()
        self.status_text = ft.Text(size=14, color=PRIMARY_COLOR, weight=ft.FontWeight.BOLD)
        
        # Build content tree and assign safely
        main_content = self._build_content()
        self._do_recalculate()
        self.content = main_content

    def _do_recalculate(self):
        """Internal recalculate that doesn't call self.update() - safe to call before mount."""
        act = safe_float(self.activity_dd.value, 25.0)
        loss = safe_float(self.loss_dd.value, 0.5)
        p_kg = safe_float(self.protein_input.value, 2.5)
        f_kg = safe_float(self.fat_input.value, 0.7)
        
        goals = calculate_macro_goals(self.weight, act, loss, p_kg, f_kg)
        
        self.summary_text.controls = [
            ft.Row([ft.Text("🔥 BMR (Jämvikt):", size=14, color=TEXT_MUTED), ft.Text(f"{goals['bmr']:.0f} kcal", size=14, weight=ft.FontWeight.BOLD, color=TEXT_PRIMARY)]),
            ft.Row([ft.Text("📉 Underskott offset:", size=14, color=TEXT_MUTED), ft.Text(f"-{goals['deficit']} kcal", size=14, weight=ft.FontWeight.BOLD, color=ft.Colors.RED_400)]),
            ft.Row([ft.Text("🎯 Dagligt kalorimål:", size=16, color=TEXT_PRIMARY), ft.Text(f"{goals['target_calories']:.0f} kcal", size=16, weight=ft.FontWeight.BOLD, color=PRIMARY_COLOR)]),
            ft.Divider(color="#1f2937"),
            ft.Row([ft.Text("🥩 Protein:", size=14, color=TEXT_MUTED), ft.Text(f"{goals['protein_goal']:.0f}g", size=14, weight=ft.FontWeight.BOLD, color=TEXT_PRIMARY)]),
            ft.Row([ft.Text("🥑 Fett:", size=14, color=TEXT_MUTED), ft.Text(f"{goals['fat_goal']:.0f}g", size=14, weight=ft.FontWeight.BOLD, color=TEXT_PRIMARY)]),
            ft.Row([ft.Text("🍞 Kolhydrater:", size=14, color=TEXT_MUTED), ft.Text(f"{goals['carb_goal']:.0f}g", size=14, weight=ft.FontWeight.BOLD, color=TEXT_PRIMARY)]),
        ]
        
        # Verify distribution percentage sum
        dist_b = safe_float(self.dist_breakfast.value, 25.0)
        dist_l = safe_float(self.dist_lunch.value, 30.0)
        dist_d = safe_float(self.dist_dinner.value, 30.0)
        dist_s = safe_float(self.dist_snack.value, 15.0)
        dist_sum = dist_b + dist_l + dist_d + dist_s
        
        meal_breakdown_controls = []
        if abs(dist_sum - 100.0) < 0.01:
            self.status_text.value = ""
            
            # Helper to get targets per meal category
            def mt(pct):
                r = pct / 100.0
                return {
                    'kcal': goals['target_calories'] * r,
                    'p': goals['protein_goal'] * r,
                    'f': goals['fat_goal'] * r,
                    'c': goals['carb_goal'] * r
                }
            
            mb, ml, ms, md = mt(dist_b), mt(dist_l), mt(dist_s), mt(dist_d)
            
            meal_breakdown_controls = [
                ft.Divider(color="#1f2937"),
                ft.Text("🍽️ Planerad Måltidsfördelning", size=14, weight=ft.FontWeight.W_600, color=TEXT_PRIMARY),
                ft.Row([
                    ft.Text("Frukost:", size=12, color=TEXT_MUTED),
                    ft.Text(f"{mb['kcal']:.0f} kcal (P:{mb['p']:.0f}g F:{mb['f']:.0f}g K:{mb['c']:.0f}g)", size=12, weight=ft.FontWeight.W_600, color=TEXT_PRIMARY)
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Row([
                    ft.Text("Lunch:", size=12, color=TEXT_MUTED),
                    ft.Text(f"{ml['kcal']:.0f} kcal (P:{ml['p']:.0f}g F:{ml['f']:.0f}g K:{ml['c']:.0f}g)", size=12, weight=ft.FontWeight.W_600, color=TEXT_PRIMARY)
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Row([
                    ft.Text("Mellanmål:", size=12, color=TEXT_MUTED),
                    ft.Text(f"{ms['kcal']:.0f} kcal (P:{ms['p']:.0f}g F:{ms['f']:.0f}g K:{ms['c']:.0f}g)", size=12, weight=ft.FontWeight.W_600, color=TEXT_PRIMARY)
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Row([
                    ft.Text("Middag:", size=12, color=TEXT_MUTED),
                    ft.Text(f"{md['kcal']:.0f} kcal (P:{md['p']:.0f}g F:{md['f']:.0f}g K:{md['c']:.0f}g)", size=12, weight=ft.FontWeight.W_600, color=TEXT_PRIMARY)
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            ]
        else:
            self.status_text.value = f"⚠️ Summan av måltider måste vara 100% (Nu: {dist_sum:.0f}%)"
            self.status_text.color = ft.Colors.ORANGE_400
            
        self.summary_text.controls.extend(meal_breakdown_controls)

    def recalculate(self, e):
        self._do_recalculate()
        try:
            self.update()
        except RuntimeError:
            pass

    def reset_macros(self, e):
        self.protein_input.value = "2.5"
        self.fat_input.value = "0.7"
        self.recalculate(None)

    def handle_save(self, e):
        # Calculate dynamic targets based on current state inputs
        act = safe_float(self.activity_dd.value, 25.0)
        loss = safe_float(self.loss_dd.value, 0.5)
        p_kg = safe_float(self.protein_input.value, 2.5)
        f_kg = safe_float(self.fat_input.value, 0.7)
        
        goals = calculate_macro_goals(self.weight, act, loss, p_kg, f_kg)
        
        dist_b = safe_float(self.dist_breakfast.value, 25.0)
        dist_l = safe_float(self.dist_lunch.value, 30.0)
        dist_d = safe_float(self.dist_dinner.value, 30.0)
        dist_s = safe_float(self.dist_snack.value, 15.0)
        
        # Verify distribution sum
        if abs((dist_b + dist_l + dist_d + dist_s) - 100.0) > 0.01:
            self.status_text.value = "⚠️ Summan av fördelningen måste vara exakt 100%!"
            self.status_text.color = ft.Colors.RED
            self.update()
            return
            
        self.status_text.value = "Sparar inställningar... 💾"
        self.update()
        
        try:
            self.shell.repo.save_user_settings(
                weight=self.weight,
                waist=self.waist,
                activity=act,
                weekly_loss=loss,
                protein_kg=p_kg,
                fat_kg=f_kg,
                protein_goal=goals['protein_goal'],
                fat_goal=goals['fat_goal'],
                carb_goal=goals['carb_goal'],
                equilibrium_calories=goals['bmr'],
                calorie_goal=goals['target_calories'],
                dist_breakfast=dist_b,
                dist_lunch=dist_l,
                dist_dinner=dist_d,
                dist_snack=dist_s,
                user_id=1
            )
            self.status_text.value = "✅ Sparat framgångsrikt!"
            self.status_text.color = PRIMARY_COLOR
            self.shell.sync_data()
        except Exception as ex:
            self.status_text.value = f"⚠️ Misslyckades att spara: {ex}"
            self.status_text.color = ft.Colors.RED
        self.update()

    def _build_content(self):
        return ft.Column(
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=20,
            scroll=ft.ScrollMode.AUTO,
            expand=True,
            controls=[
                ft.Container(
                    content=ft.Column(
                        controls=[
                            ft.Text("Din kaloriberäkning 🎯", size=24, weight=ft.FontWeight.BOLD, color=TEXT_PRIMARY),
                            ft.Text("Justera aktivitetsnivå, macros, och energifördelning.", size=14, color=TEXT_MUTED),
                        ]
                    ),
                    padding=ft.Padding(0, 10, 0, 10),
                    alignment=ft.alignment.Alignment(-1, 0)
                ),
                # Panel controls
                ft.Container(
                    content=ft.Column(
                        spacing=16,
                        controls=[
                            self.activity_dd,
                            self.loss_dd,
                            ft.Row([
                                ft.Text("🥩 Proteinkrav & Fett", size=16, weight=ft.FontWeight.W_600, color=TEXT_PRIMARY),
                                ft.IconButton(
                                    icon=ft.Icons.REFRESH,
                                    icon_color=PRIMARY_COLOR,
                                    tooltip="Återställ till standard (Protein 2.5g, Fett 0.7g)",
                                    on_click=self.reset_macros
                                )
                            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                            self.protein_input,
                            self.fat_input,
                            ft.Text("🥞 Fördelning per måltidstyp (%)", size=16, weight=ft.FontWeight.W_600, color=TEXT_PRIMARY),
                            ft.Row([self.dist_breakfast, self.dist_lunch], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                            ft.Row([self.dist_dinner, self.dist_snack], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                            ft.Divider(color="#1f2937"),
                            self.summary_text,
                            self.status_text,
                            ft.ElevatedButton(
                                content=ft.Row([
                                    ft.Icon(ft.Icons.SAVE, color=TEXT_PRIMARY, size=18),
                                    ft.Text("Spara Mål", color=TEXT_PRIMARY, weight=ft.FontWeight.BOLD)
                                ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
                                bgcolor=PRIMARY_COLOR,
                                color=TEXT_PRIMARY,
                                on_click=self.handle_save,
                                style=ft.ButtonStyle(
                                    shape=ft.RoundedRectangleBorder(radius=8),
                                    padding=16
                                ),
                                width=320
                            ),
                            ft.Divider(color="#1f2937"),
                            ft.Text("Google Sheets Anslutning ☁️", size=16, weight=ft.FontWeight.W_600, color=TEXT_PRIMARY),
                            ft.Text("Koppla från eller byt Google Sheets-konto.", size=12, color=TEXT_MUTED),
                            ft.OutlinedButton(
                                content=ft.Row([
                                    ft.Icon(ft.Icons.LOGOUT, color=ft.Colors.RED_400, size=18),
                                    ft.Text("Koppla från Google Sheets 🔓", color=ft.Colors.RED_400, weight=ft.FontWeight.BOLD)
                                ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
                                on_click=lambda e: self.shell.handle_logout(),
                                style=ft.ButtonStyle(
                                    shape=ft.RoundedRectangleBorder(radius=8),
                                    padding=16,
                                    side={ft.ControlState.DEFAULT: ft.BorderSide(1, ft.Colors.RED_900)}
                                ),
                                width=320
                            )
                        ]
                    ),
                    padding=24,
                    bgcolor=CARD_BG,
                    border_radius=12,
                    border=ft.Border(
                        top=ft.BorderSide(1, "#1f2937"),
                        bottom=ft.BorderSide(1, "#1f2937"),
                        left=ft.BorderSide(1, "#1f2937"),
                        right=ft.BorderSide(1, "#1f2937")
                    ),
                    width=360
                )
            ]
        )