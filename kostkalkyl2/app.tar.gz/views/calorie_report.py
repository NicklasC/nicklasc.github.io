import flet as ft
from datetime import date, timedelta
from src.core.theme import PRIMARY_COLOR, TEXT_PRIMARY, TEXT_MUTED, CARD_BG
from src.repositories.google_sheets_repo import safe_float
from src.core.calculations import calculate_predicted_weight_change

class CalorieReportView(ft.Container):
    def __init__(self, shell):
        # 1. Initialize parent class first with expand=True to prevent Flet expand=None ValueError bug
        super().__init__(expand=True)
        
        self.shell = shell
        
        # Build content tree and assign safely
        main_content = self._build_content()
        self.content = main_content

    def _build_content(self):
        # 1. Get stats from repo
        try:
            weekly_stats = self.shell.repo.get_weekly_breakdown(self.shell.selected_date)
        except Exception as e:
            print(f"Error loading weekly breakdown: {e}")
            weekly_stats = []
            
        # Dags diff for today
        intake_today, burned_today, macros_today, _ = self.shell.repo.get_daily_summary(self.shell.selected_date)
        user_settings = self.shell.user_settings or {}
        target_today = user_settings.get("target_calories", 2000.0)
        diff_today = target_today - intake_today
        
        diff_color_today = PRIMARY_COLOR if diff_today >= 0 else ft.Colors.RED_400
        
        # Header overview cards
        overview_row = ft.Row(
            spacing=10,
            controls=[
                ft.Container(
                    content=ft.Column([
                        ft.Text("🍽️ Intag", size=11, color=TEXT_MUTED),
                        ft.Text(f"{intake_today:.0f}", size=20, weight=ft.FontWeight.BOLD, color=TEXT_PRIMARY),
                        ft.Text("kcal", size=10, color=TEXT_MUTED)
                    ], spacing=2),
                    bgcolor=CARD_BG,
                    padding=12,
                    border_radius=8,
                    expand=True,
                    alignment=ft.Alignment(0, 0)
                ),
                ft.Container(
                    content=ft.Column([
                        ft.Text("🎯 Mål", size=11, color=TEXT_MUTED),
                        ft.Text(f"{target_today:.0f}", size=20, weight=ft.FontWeight.BOLD, color=TEXT_PRIMARY),
                        ft.Text("kcal", size=10, color=TEXT_MUTED)
                    ], spacing=2),
                    bgcolor=CARD_BG,
                    padding=12,
                    border_radius=8,
                    expand=True,
                    alignment=ft.Alignment(0, 0)
                ),
                ft.Container(
                    content=ft.Column([
                        ft.Text("⚖️ Kvar", size=11, color=TEXT_MUTED),
                        ft.Text(f"{diff_today:+.0f}", size=20, weight=ft.FontWeight.BOLD, color=diff_color_today),
                        ft.Text("kcal", size=10, color=TEXT_MUTED)
                    ], spacing=2),
                    bgcolor=CARD_BG,
                    padding=12,
                    border_radius=8,
                    expand=True,
                    alignment=ft.Alignment(0, 0)
                )
            ]
        )
        
        # 2. Build Swedish weekly breakdown tiles
        tiles = []
        total_weekly_diff = 0.0
        
        sw_months = ["jan", "feb", "mar", "apr", "maj", "jun", "jul", "aug", "sep", "okt", "nov", "dec"]
        
        for idx, day in enumerate(weekly_stats):
            d = day['date']
            intake = day['intake']
            target = day['target']
            diff = day['diff']
            meals = day['meals']
            
            # Formatting
            date_str = f"{d.day} {sw_months[d.month-1]} ({day['day_name']})"
            
            # Future days or empty days check
            is_future = d > date.today()
            
            if is_future:
                subtitle_text = "Ingen data (Framtid)"
                sub_color = TEXT_MUTED
                diff_text = "-"
                diff_val = 0.0
            elif meals.empty:
                subtitle_text = "Inga registrerade måltider"
                sub_color = TEXT_MUTED
                diff_text = "-"
                diff_val = 0.0
            else:
                subtitle_text = f"Intag: {intake:.0f} kcal  •  Mål: {target:.0f} kcal"
                sub_color = PRIMARY_COLOR if diff <= 0 else ft.Colors.RED_400
                diff_text = f"{diff:+.0f} kcal"
                diff_val = diff
                # Only sum past/present days with data
                total_weekly_diff += diff_val
                
            # Build expanding meals list
            meal_rows = []
            if not meals.empty:
                # Group by Category
                categories = ["Frukost", "Lunch", "Middag", "Mellanmål", "Övrigt"]
                for cat in categories:
                    cat_meals = meals[meals['Kategori'] == cat]
                    if not cat_meals.empty:
                        # Category header
                        c_kcal = cat_meals['Kcal'].sum()
                        c_p = cat_meals['Protein'].sum()
                        c_f = cat_meals['Fett'].sum()
                        c_c = cat_meals['Kolhydrater'].sum()
                        
                        meal_rows.append(
                            ft.Container(
                                content=ft.Row([
                                    ft.Text(f"🍳 {cat}", size=13, weight=ft.FontWeight.BOLD, color=PRIMARY_COLOR),
                                    ft.Text(f"{c_kcal:.0f} kcal (P:{c_p:.0f} F:{c_f:.0f} K:{c_c:.0f})", size=11, color=TEXT_MUTED)
                                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                                padding=ft.Padding(0, 4, 0, 4)
                            )
                        )
                        
                        # Category item rows
                        for _, row in cat_meals.iterrows():
                            meal_rows.append(
                                ft.Container(
                                    content=ft.Row([
                                        ft.Text(f"  • {row['Namn']} ({row['Mängd']} port)", size=12, color=TEXT_PRIMARY),
                                        ft.Text(f"{safe_float(row['Kcal']):.0f} kcal", size=12, color=TEXT_MUTED)
                                    ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                                    padding=ft.Padding(8, 2, 8, 2)
                                )
                            )
            else:
                meal_rows.append(ft.Text("Inga detaljerade måltider att visa.", color=TEXT_MUTED, italic=True))
                
            # Material 3 Expansion Tile
            tiles.append(
                ft.ExpansionTile(
                    title=ft.Text(date_str, size=14, weight=ft.FontWeight.W_600, color=TEXT_PRIMARY),
                    subtitle=ft.Text(subtitle_text, size=11, color=sub_color),
                    trailing=ft.Text(diff_text, size=14, weight=ft.FontWeight.BOLD, color=sub_color),
                    bgcolor=CARD_BG,
                    collapsed_bgcolor=CARD_BG,
                    controls=[
                        ft.Container(
                            content=ft.Column(controls=meal_rows, spacing=4),
                            padding=12,
                            bgcolor="#090d16",
                            border_radius=8
                        )
                    ],
                    expanded=(d == self.shell.selected_date)
                )
            )
            
        # Predicted weight change
        predicted_loss = calculate_predicted_weight_change(total_weekly_diff)
        summary_color = PRIMARY_COLOR if total_weekly_diff <= 0 else ft.Colors.RED_400
        
        weekly_summary_card = ft.Container(
            content=ft.Column([
                ft.Text("📅 Sammanfattning för veckan", size=16, weight=ft.FontWeight.BOLD, color=TEXT_PRIMARY),
                ft.Row([
                    ft.Text("Ackumulerad diff:", size=13, color=TEXT_MUTED),
                    ft.Text(f"{total_weekly_diff:+.0f} kcal", size=13, weight=ft.FontWeight.BOLD, color=summary_color)
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Row([
                    ft.Text("Beräknad viktändring:", size=13, color=TEXT_MUTED),
                    ft.Text(f"{predicted_loss:+.2f} kg", size=13, weight=ft.FontWeight.BOLD, color=TEXT_PRIMARY)
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)
            ]),
            padding=16,
            bgcolor=CARD_BG,
            border_radius=12,
            border=ft.Border(
                top=ft.BorderSide(1, "#1f2937"),
                bottom=ft.BorderSide(1, "#1f2937"),
                left=ft.BorderSide(1, "#1f2937"),
                right=ft.BorderSide(1, "#1f2937")
            )
        )
        
        # Build UI layout
        return ft.Column(
            spacing=16,
            scroll=ft.ScrollMode.AUTO,
            expand=True,
            controls=[
                ft.Container(
                    content=ft.Column([
                        ft.Text("📊 Kalorirapport", size=24, weight=ft.FontWeight.BOLD, color=TEXT_PRIMARY),
                        ft.Text("Din veckoanalys med detaljerade måltidsförgreningar.", size=14, color=TEXT_MUTED)
                    ]),
                    padding=ft.Padding(0, 10, 0, 10)
                ),
                overview_row,
                ft.Column(controls=tiles, spacing=8),
                weekly_summary_card
            ]
        )