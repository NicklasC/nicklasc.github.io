import flet as ft
import json
from src.core.theme import BG_COLOR, PRIMARY_COLOR, TEXT_PRIMARY, TEXT_MUTED, CARD_BG, BORDER_COLOR
from src.core.config import parse_google_credentials
from src.core.credential_store import (
    CredentialDecryptionError,
    ENCRYPTED_CREDENTIALS_KEY,
    LEGACY_PLAINTEXT_CREDENTIALS_KEY,
    SPREADSHEET_URL_KEY,
    decrypt_credentials,
    encrypt_credentials,
    validate_passphrase,
)
from src.repositories.google_sheets_repo import GoogleSheetsRepository

class SetupView(ft.Container):
    def __init__(
        self,
        on_success,
        encrypted_credentials=None,
        spreadsheet_url=None,
    ):
        super().__init__(expand=True)
        self.on_success = on_success
        self.encrypted_credentials = encrypted_credentials
        self.is_unlock_mode = encrypted_credentials is not None
        self.preferences = ft.SharedPreferences()
        
        # Input elements
        self.url_input = ft.TextField(
            label="Google Kalkylark URL 📊",
            hint_text="https://docs.google.com/spreadsheets/d/...",
            value=spreadsheet_url or "",
            visible=not self.is_unlock_mode or not spreadsheet_url,
            width=320,
            border_color=BORDER_COLOR,
            focused_border_color=PRIMARY_COLOR,
            bgcolor="#090d16",
            text_size=13,
            label_style=ft.TextStyle(color=TEXT_MUTED),
            hint_style=ft.TextStyle(color=TEXT_MUTED)
        )
        
        self.creds_input = ft.TextField(
            label="Google Service Account JSON 🔑",
            hint_text="Klistra in hela innehållet från din .json-nyckel här...",
            visible=not self.is_unlock_mode,
            multiline=True,
            min_lines=6,
            max_lines=12,
            width=320,
            border_color=BORDER_COLOR,
            focused_border_color=PRIMARY_COLOR,
            bgcolor="#090d16",
            text_size=11,
            label_style=ft.TextStyle(color=TEXT_MUTED),
            hint_style=ft.TextStyle(color=TEXT_MUTED)
        )

        self.passphrase_input = ft.TextField(
            label=(
                "Lösenfras för att låsa upp"
                if self.is_unlock_mode
                else "Ny lösenfras (minst 12 tecken)"
            ),
            password=True,
            can_reveal_password=True,
            width=320,
            border_color=BORDER_COLOR,
            focused_border_color=PRIMARY_COLOR,
            bgcolor="#090d16",
            text_size=13,
            label_style=ft.TextStyle(color=TEXT_MUTED),
        )
        self.confirm_passphrase_input = ft.TextField(
            label="Bekräfta lösenfras",
            password=True,
            can_reveal_password=True,
            visible=not self.is_unlock_mode,
            width=320,
            border_color=BORDER_COLOR,
            focused_border_color=PRIMARY_COLOR,
            bgcolor="#090d16",
            text_size=13,
            label_style=ft.TextStyle(color=TEXT_MUTED),
        )
        
        # Loader & feedback text
        self.loader = ft.ProgressRing(width=20, height=20, stroke_width=2, visible=False)
        self.status_text = ft.Text(value="", size=13, color=ft.Colors.RED_400, text_align=ft.TextAlign.CENTER, width=320)
        self.connect_btn = ft.ElevatedButton(
            content=ft.Row([
                ft.Icon(ft.Icons.CLOUD_SYNC, color=TEXT_PRIMARY, size=18),
                ft.Text(
                    "Lås upp & Anslut"
                    if self.is_unlock_mode
                    else "Kryptera & Anslut",
                    color=TEXT_PRIMARY,
                    weight=ft.FontWeight.BOLD,
                )
            ], alignment=ft.MainAxisAlignment.CENTER, spacing=8),
            bgcolor=PRIMARY_COLOR,
            color=TEXT_PRIMARY,
            on_click=self.handle_connect,
            style=ft.ButtonStyle(
                shape=ft.RoundedRectangleBorder(radius=8),
                padding=16
            ),
            width=320
        )
        
        # Layout build
        self.content = self._build_ui()
        self.bgcolor = BG_COLOR
        self.alignment = ft.Alignment.CENTER

    async def handle_connect(self, e):
        url = self.url_input.value.strip()
        passphrase = self.passphrase_input.value or ""

        if not passphrase:
            self.status_text.value = "⚠️ Lösenfrasen saknas!"
            self.status_text.color = ft.Colors.ORANGE_400
            self.update()
            return
        
        if not url:
            self.status_text.value = "⚠️ Kalkylarkets URL saknas!"
            self.status_text.color = ft.Colors.ORANGE_400
            self.update()
            return
            
        if not self.is_unlock_mode:
            creds_str = self.creds_input.value.strip()
            if not creds_str:
                self.status_text.value = "⚠️ Google Service Account JSON saknas!"
                self.status_text.color = ft.Colors.ORANGE_400
                self.update()
                return
            if passphrase != (self.confirm_passphrase_input.value or ""):
                self.status_text.value = "⚠️ Lösenfraserna matchar inte."
                self.status_text.color = ft.Colors.ORANGE_400
                self.update()
                return
            
        # Clear previous state and show loader
        self.status_text.value = "Försöker ansluta till Google Sheets... 🔄"
        self.status_text.color = PRIMARY_COLOR
        self.connect_btn.disabled = True
        self.loader.visible = True
        self.update()
        
        try:
            if self.is_unlock_mode:
                creds_info = decrypt_credentials(
                    self.encrypted_credentials,
                    passphrase,
                )
            else:
                validate_passphrase(passphrase)
                try:
                    creds_data = json.loads(creds_str)
                except Exception:
                    raise ValueError(
                        "Ogiltigt JSON-format. Se till att du kopierade hela texten."
                    )
                creds_info, _ = parse_google_credentials(creds_data)
            
            # 2. Test Connection by instantiating repo and fetching metadata
            repo = GoogleSheetsRepository(creds_info=creds_info, spreadsheet_url=url)
            
            # Perform a quick verification read to ensure sheet exists and user has rights
            repo.get_latest_measurement()
            
            # Persist only an authenticated encrypted bundle. The passphrase
            # and plaintext service-account key remain session-only.
            if not self.is_unlock_mode:
                encrypted_bundle = encrypt_credentials(creds_info, passphrase)
                await self.preferences.set(
                    ENCRYPTED_CREDENTIALS_KEY,
                    encrypted_bundle,
                )
                await self.preferences.set(SPREADSHEET_URL_KEY, url)
                await self.preferences.remove(LEGACY_PLAINTEXT_CREDENTIALS_KEY)

            self.passphrase_input.value = ""
            self.confirm_passphrase_input.value = ""
            
            self.status_text.value = "✅ Ansluten! Startar appen..."
            self.status_text.color = PRIMARY_COLOR
            self.update()
            
            # 4. Success callback
            self.on_success(repo)
        except CredentialDecryptionError:
            self.status_text.value = "❌ Fel lösenfras eller skadade sparade uppgifter."
            self.status_text.color = ft.Colors.RED_400
            self.connect_btn.disabled = False
            self.loader.visible = False
            self.update()
        except Exception as err:
            err_msg = str(err)
            if "Permission denied" in err_msg or "service account" in err_msg.lower() or "not found" in err_msg.lower():
                self.status_text.value = (
                    "❌ Anslutningsfel!\n\n"
                    "Kontrollera:\n"
                    "1. Har du delat ditt Google Sheet med klient-epostadressen (client_email) i JSON-filen?\n"
                    "2. Har du gett den behörighet som 'Redigerare' (Editor)?\n"
                    "3. Är kalkylarkets URL helt korrekt?"
                )
            else:
                self.status_text.value = (
                    "❌ Kunde inte ansluta till kalkylarket. Kontrollera "
                    "uppgifterna och försök igen."
                )
            self.status_text.color = ft.Colors.RED_400
            self.connect_btn.disabled = False
            self.loader.visible = False
            self.update()

    def _build_ui(self):
        if self.is_unlock_mode:
            subtitle = "Lås upp den krypterade Google Sheets-kopplingen"
            instruction_controls = [
                ft.Text(
                    "🔒 Din servicekontonyckel är krypterad",
                    size=14,
                    weight=ft.FontWeight.W_600,
                    color=TEXT_PRIMARY,
                ),
                ft.Text(
                    "Ange lösenfrasen för att ansluta. Lösenfrasen sparas inte.",
                    size=12,
                    color=TEXT_MUTED,
                ),
            ]
        else:
            subtitle = "Konfigurera din Google Sheets-koppling"
            instruction_controls = [
                ft.Text("📋 Snabbguide för installation", size=14, weight=ft.FontWeight.W_600, color=TEXT_PRIMARY),
                ft.Text("1. Skapa ett Google Kalkylark med dina flikar.", size=12, color=TEXT_MUTED),
                ft.Text("2. Skapa ett Service Account i Google Cloud Console.", size=12, color=TEXT_MUTED),
                ft.Text("3. Ladda ner din .json-nyckelfil.", size=12, color=TEXT_MUTED),
                ft.Text("4. DELA ditt Google Sheet som 'Redigerare' (Editor) med e-postadressen som står i din JSON-fil (fältet client_email).", size=12, color=PRIMARY_COLOR, weight=ft.FontWeight.W_500),
                ft.Text("5. Välj en unik lösenfras som skyddar nyckeln på enheten.", size=12, color=TEXT_MUTED),
            ]

        return ft.Column(
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=16,
            scroll=ft.ScrollMode.AUTO,
            controls=[
                # Header Logo
                ft.Container(
                    content=ft.Column(
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        spacing=8,
                        controls=[
                            ft.Icon(ft.Icons.RESTAURANT_MENU, color=PRIMARY_COLOR, size=48),
                            ft.Text("KostKalkyl", size=28, weight=ft.FontWeight.BOLD, color=TEXT_PRIMARY),
                            ft.Text(subtitle, size=13, color=TEXT_MUTED),
                        ]
                    ),
                    padding=ft.Padding(0, 20, 0, 10)
                ),
                
                # Instruction Card
                ft.Container(
                    content=ft.Column(spacing=10, controls=instruction_controls),
                    padding=16,
                    bgcolor="#0e1320",
                    border_radius=8,
                    border=ft.Border(
                        top=ft.BorderSide(1, BORDER_COLOR),
                        bottom=ft.BorderSide(1, BORDER_COLOR),
                        left=ft.BorderSide(1, BORDER_COLOR),
                        right=ft.BorderSide(1, BORDER_COLOR)
                    ),
                    width=340
                ),
                
                # Inputs Card
                ft.Container(
                    content=ft.Column(
                        spacing=16,
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        controls=[
                            self.url_input,
                            self.creds_input,
                            self.passphrase_input,
                            self.confirm_passphrase_input,
                            ft.Row([self.loader], alignment=ft.MainAxisAlignment.CENTER),
                            self.status_text,
                            self.connect_btn
                        ]
                    ),
                    padding=24,
                    bgcolor=CARD_BG,
                    border_radius=12,
                    border=ft.Border(
                        top=ft.BorderSide(1, BORDER_COLOR),
                        bottom=ft.BorderSide(1, BORDER_COLOR),
                        left=ft.BorderSide(1, BORDER_COLOR),
                        right=ft.BorderSide(1, BORDER_COLOR)
                    ),
                    width=360
                )
            ]
        )
